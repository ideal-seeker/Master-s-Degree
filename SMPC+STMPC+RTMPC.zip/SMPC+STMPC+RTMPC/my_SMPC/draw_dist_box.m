function  []= draw_dist_box(dist,w_mean,w_cov,multiple,facecolor)
num=15;
[X,Y] = meshgrid(linspace(min(dist.V(:,1)),max(dist.V(:,1)),num),...
    linspace(min(dist.V(:,2)),max(dist.V(:,2)),num)); 
[rows,cols] = size(X); 
x = reshape(X,rows*cols,1);
y = reshape(Y,rows*cols,1);
p = [x,y];
z = mvnpdf(p,w_mean,w_cov)/multiple;     			%求得网格点上的概率密度
Z = reshape(z,rows,cols);
size(Z)
surf(X,Y,Z,'FaceColor',facecolor);


% %画边界
% min_x = min(dist.V(:,1));
% max_x = max(dist.V(:,1));
% min_y = min(dist.V(:,2));
% max_y = max(dist.V(:,2));
% num_edge = 100;
% X_edge = [min_x*ones(1,num_edge),linspace(min_x,max_x,num_edge),max_x*ones(1,num_edge),linspace(max_x,min_x,num_edge-1)]';
% Y_edge = [linspace(min_y,max_y,num_edge),min_y*ones(1,num_edge),linspace(max_y,min_y,num_edge),max_y*ones(1,num_edge-1)]';
% size(X_edge)
% size(Y_edge)
% p_edge = [X_edge,Y_edge];
% z_edge = mvnpdf(p_edge,w_mean,w_cov)/multiple; 
% plot3(X_edge,Y_edge,z_edge,'Color','r', 'LineWidth', 2);
end

