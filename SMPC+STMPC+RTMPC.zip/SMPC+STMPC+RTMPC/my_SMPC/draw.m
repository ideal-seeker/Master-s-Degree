feasible_region_origin = Polyhedron('A',g','b',h);
feasible_region_ours_1 = Polyhedron('A',g','b',h-h_tighten(1));
feasible_region_ours_2 = Polyhedron('A',g','b',h-h_tighten(2));
feasible_region_ours_3 = Polyhedron('A',g','b',h-h_tighten(3));
feasible_region_ours_4 = Polyhedron('A',g','b',h-h_tighten(4));
feasible_region_ours_5 = Polyhedron('A',g','b',h-h_tighten(5));
feasible_region_ours_6 = Polyhedron('A',g','b',h-h_tighten(6));
boxrmpc=box_shaped_CR(w_cov,p_ref);
[it,minrpi_of_e] = compute_minRPI(Phi,boxrmpc,0.05);
feasible_region_rmpc=feasible_region_origin-minrpi_of_e;
feasible_region_stmpc=Polyhedron('A',AA,'b',bb);
% feasible_region_cannon;
figure (2)%第一步可行集对比


text(0,0,'origin','FontSize',14,Color='g');
text(feasible_region_ours_1.V(1),feasible_region_ours_1.V(2),'ours','FontSize',14,Color='r');
text(feasible_region_rmpc.V(1),feasible_region_rmpc.V(2),'rmpc','FontSize',14,Color='b');


x_zuobiao = 0.5:0.01:1.0;
origin = (feasible_region_origin.b-feasible_region_origin.A(1)*x_zuobiao)/feasible_region_origin.A(2);
ours_1 = (feasible_region_ours_1.b-feasible_region_ours_1.A(1)*x_zuobiao)/feasible_region_ours_1.A(2);
ours_2 = (feasible_region_ours_2.b-feasible_region_ours_2.A(1)*x_zuobiao)/feasible_region_ours_2.A(2);
ours_3 = (feasible_region_ours_3.b-feasible_region_ours_3.A(1)*x_zuobiao)/feasible_region_ours_3.A(2);
ours_4 = (feasible_region_ours_4.b-feasible_region_ours_4.A(1)*x_zuobiao)/feasible_region_ours_4.A(2);
ours_5 = (feasible_region_ours_5.b-feasible_region_ours_5.A(1)*x_zuobiao)/feasible_region_ours_5.A(2);
ours_6 = (feasible_region_ours_6.b-feasible_region_ours_6.A(1)*x_zuobiao)/feasible_region_ours_6.A(2);
rmpc = (feasible_region_rmpc.b-feasible_region_rmpc.A(1)*x_zuobiao)/feasible_region_rmpc.A(2);
stmpc = (feasible_region_stmpc.b-feasible_region_stmpc.A(1)*x_zuobiao)/feasible_region_stmpc.A(2);

area(x_zuobiao,origin,'FaceColor','#FFE0C1','LineStyle','-');
hold on
% area(x_zuobiao,ours_1,'FaceColor','#5861AC','LineStyle','-');
% hold on
% area(x_zuobiao,ours_2,'FaceColor','#FF7F00','LineStyle','-');
% hold on
% area(x_zuobiao,ours_3,'FaceColor','#A5C2E2','LineStyle','-');
% hold on
% area(x_zuobiao,ours_4,'FaceColor','#70B48F','LineStyle','-');
% hold on
% area(x_zuobiao,ours_5,'FaceColor','#F28080','LineStyle','-');
% hold on
% % area(x_zuobiao(1,35:51),rmpc(1,35:51),'FaceColor','#D7DCBE','LineStyle','-');
% % hold on
% % area(x_zuobiao(1,18:35),stmpc(1,18:35),'FaceColor','#63BA45','LineStyle','-');
% % hold on
% % area(x_zuobiao(1,1:18),ours_1(1,1:18),'FaceColor','#E84445','LineStyle','-');
% % hold on
% % plot(x_zuobiao(1,1:35),rmpc(1,1:35),'color','#D7DCBE','Linestyle', '--');
% % hold on
% % plot(x_zuobiao(1,[1:18,35:51]),stmpc(1,[1:18,35:51]),'color','#63BA45','Linestyle', '--');
% % hold on
% % plot(x_zuobiao(1,18:51),ours_1(1,18:51),'color','#E84445','Linestyle', '--');


area(x_zuobiao,ours_1,'FaceColor','#E84445','LineStyle','-');
hold on
area(x_zuobiao,stmpc,'FaceColor','#63BA45','LineStyle','-');
hold on
area(x_zuobiao,rmpc,'FaceColor','#D7DCBE','LineStyle','-');
hold on

xlabel('x_1');
ylabel('x_2');
% alpha(0.1)
title('Contrained regions');
% legend('origin','ours\_1','ours\_2','ours\_3','ours\_4','ours\_5','ours\_6','STMPC','tube-based RMPC','Location','best') ;%可依次设置成你想要的名字
legend('Original','Ours','STMPC','tube-based RMPC','Location','best') ;%可依次设置成你想要的名字
%%画扰动范围
figure (3)

draw_dist_box(boxrmpc,w_mean,w_cov,p_ref,'#A6CEE3');

hold on
draw_dist_circle([0,0],sqrt(alpha_bar),w_mean,w_cov, 0.7906,'#FB9A99')%0.7906是最大范围时园内的分布函数值
hold on
draw_dist_box(Polyhedron([-1,-1;-1,1;1,1;1,-1]*0.6),w_mean,w_cov,1,'#FDBF6F');

hold on

 % 设置填充颜色和边界线颜色
title('Probability density of uncertainty')
legend('tube based RMPC','STMPC','ours','Location','best');

figure(4)
subplot(2,2,1);
area(x_zuobiao, origin, 'FaceColor', '#FFE0C1', 'LineStyle', '-');
title('Original Feasible Region');
xlabel('x1');
ylabel('x2');
xlim([x_zuobiao(1) x_zuobiao(51)]);
ylim([0 3]);
grid on;

% 第二个子图：OURS
subplot(2,2,2);
area(x_zuobiao, ours_1, 'FaceColor', '#E84445', 'LineStyle', '-');
title('OURS Feasible Region');
xlabel('x1');
ylabel('x2');
xlim([x_zuobiao(1) x_zuobiao(51)]);
ylim([0 3]);
grid on;

% 第三个子图：STMPC
subplot(2,2,3);
area(x_zuobiao, stmpc, 'FaceColor', '#63BA45', 'LineStyle', '-');
title('STMPC Feasible Region');
xlabel('x1');
ylabel('x2');
xlim([x_zuobiao(1) x_zuobiao(51)]);
ylim([0 3]);
grid on;

% 第四个子图：RMPC
subplot(2,2,4);
area(x_zuobiao, rmpc, 'FaceColor', '#D7DCBE', 'LineStyle', '-');
title('RMPC Feasible Region');
xlabel('x1');
ylabel('x2');
xlim([x_zuobiao(1) x_zuobiao(51)]);
ylim([0 3]);
grid on;

