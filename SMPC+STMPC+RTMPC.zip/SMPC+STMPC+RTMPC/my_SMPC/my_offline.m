clear ;
clc;
addpath("my_SMPC\");
addpath("tube_smpc_easy\");

%离线部分要做的事
%概率约束设定概率\in[0,1]
p_ref=0.6;
%初始化系统
A = [1.8 -0.5;-1.5 1.2];
B = [2;1];
%初始化扰动
w_mean=[0;0];
w_cov=diag([0.02,0.04]);
%初始化约束
g = [-1.75 1]';
h = 1.1;
%初始化预测时域
N=6;
N_hat=6;
n_star=0;
N_all = N+N_hat+n_star;
%代价权重
Q=diag([5,5]);
R=1;
%LQR计算反馈系数
[K_tmp, ~] = dlqr(A, B, Q, R);
K=-K_tmp;
Phi=A+B*K;
%计算e和g^Te的概率性质
e_mean=[0;0];
e_cov=zeros(2,2*N_all);
gTe_mean=0;
gTe_cov=zeros(1,N_all);
gTe_sqrt_cov=zeros(1,N_all);
gTw_cov=zeros(1,N_all);
gTw_sqrt_cov=zeros(1,N_all);
for i = 1:1:N_all
    left=0;
    for j=1:1:i
        left=left+Phi^(i-j);
    end
    right=left';
    e_cov(:,(2*i-1:2*i))=left*w_cov*right;
    gTe_cov(i)=g'*e_cov(:,(2*i-1:2*i))*g;
    gTe_sqrt_cov(i)=sqrt(gTe_cov(i));

    left_sigma=g'*Phi^(i);
    right_sigma=left_sigma';
    gTw_cov(i)=left_sigma*w_cov*right_sigma;
    gTw_sqrt_cov(i)=sqrt(gTw_cov(i));
end
%约束收紧参数确定
h_tighten=zeros(1,N_all);
for j = 1:1:N_all
    h_tighten(j)=norminv(p_ref,gTe_mean,gTe_sqrt_cov(1));
    for r=1:1:j-1
        h_tighten(j)=h_tighten(j)+3*gTw_sqrt_cov(r);
    end
end

%进一步收紧终端约束，这个写成函数在online的时候用吧
% （求鲁棒正不变集）(写成函数)

%盒型扰动定界，这个也弄成函数
% boxCR=box_shaped_CR(w_cov,p_ref);

