% % clear;
% % clc;
% % A = [0.8916 0.1225;-0.1225 0.8916];
% % B = [0;0]; 
% % Phi = A;%非自治系统这里要有个LQR算Phi
% % W_vertex = [0.01, 0.01; 0.01, -0.01; -0.01, -0.01; -0.01, 0.01]; % construct a convex set of disturbance (2dim here)
% % W = Polyhedron(W_vertex);
% % Xc_vertex = [100, -20; 100 100; -100 100; -100 -20];
% % Uc_vertex = [1; -1];
% % Xc = Polyhedron(Xc_vertex);
% % O_infty = compute_MAXRPI(Phi,W,Xc);
% % plot(O_infty)
% ww=box_shaped_CR(w_cov,p_ref);
% [it,z]=compute_minRPI(Phi,ww,0.05);
% figure;
% plot(z)
% % patch('Vertices% 定义非闭合的多边形的顶点坐标
% % V = [0 0 0; 1 0 0; 1 1 0; 0.5 1.5 0; 0 1 0];
% % 
% % % 定义多边形的面索引
% % F = [1 2 3 4 5];
% % 
% % % 绘制非闭合的多边形
% % % 定义无界面的顶点坐标
% % V = [0 0 0; 1 0 0; 1 1 0; 0 1 0; 0.5 0.5 1];  % 顶点坐标
% % 
% % % 定义无界面的面索引
% % F = [1 2 3 4];  % 四边形面的顶点索引
% 
% % % 绘制无界面的平面区域
% % figure;
% % patch('Vertices', V, 'Faces', F, 'FaceColor', 'cyan', 'EdgeColor', 'none', 'FaceAlpha', 0.5);
% % xlabel('X'); ylabel('Y'); zlabel('Z');
% % view(3); % 设置视角为三维
% % 
% % axis equal; % 设置坐标轴比例相等
% % grid on; % 显示网
% % V = [0 0 0; 1 0 0; 0.5 sqrt(3)/2 0; 0.5 1/3 sqrt(6)/3];  % 四面体的顶点坐标
% % F = [1 2 3; 1 2 4; 2 3 4; 1 3 4];  % 四面体的四个三角形面的顶点索引
% % 
% % % 绘制四面体
% % figure;
% % patch('Vertices', V, 'Faces', F, 'FaceColor', 'cyan', 'EdgeColor', 'k');
% % xlabel('X'); ylabel('Y'); zlabel('Z');
% % view(3); % 设置视角为三维
% % 
% % axis equal; % 设置坐标轴比例相等
% % grid on; % 显示网格
% 创建一些示例数据
x = 1:10;
y1 = randi([1, 10], 1, 10);
y2 = randi([1, 10], 1, 10);

% 绘制面积图
area(x, [y1; y2]');

% 设置面积图的属性
hold on; % 保持图形，以便在其上添加更多图形
line(x, y1, 'Color', 'r', 'LineWidth', 1.5); % 添加红色边界线条
% line(x, y2, 'Color', 'r', 'LineWidth', 1.5); % 添加红色边界线条

% 添加图例和标签
legend('Area 1', 'Area 2', 'Location', 'Best');
xlabel('X');
ylabel('Y');
title('Area Plot with Red Borders');
