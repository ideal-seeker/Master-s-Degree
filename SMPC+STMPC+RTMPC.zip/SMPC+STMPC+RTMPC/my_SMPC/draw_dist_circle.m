function [] = draw_dist_circle(mid,r,w_mean,w_cov,multiple,facecolor)
xc = mid(1); % 圆心 x 坐标
yc = mid(2); % 圆心 y 坐标
num=30;

% 生成随机点
num_points = num*num; % 要生成的点的数量
theta = 2 * pi * (linspace(-1,1,num))'; % 随机角度
rho = r * (linspace(-1,1,num)); % 随机半径

% 将极坐标转换为直角坐标
x = reshape(xc + rho .* cos(theta),num_points,1);
y = reshape(yc + rho .* sin(theta),num_points,1);
size(x);
size(y);
p=[x,y];
size(p)
% 绘制圆和生成的点
z = mvnpdf(p,w_mean,w_cov)/multiple; 
X=reshape(x,num,num);
Y=reshape(y,num,num);
Z=reshape(z,num,num);
surf(X,Y,Z,'FaceColor', facecolor);

% hold on
% %画边界
% theta_edge = 2 * pi * (linspace(-1,1,num_points))'; % 随机角度
% rho_edge = r; % 随机半径
% x_edge = reshape(0 + rho_edge* cos(theta_edge),num_points,1);
% y_edge = reshape(0 + rho_edge* sin(theta_edge),num_points,1);
% p_edge=[x_edge,y_edge];
% z_edge = mvnpdf(p_edge,w_mean,w_cov)/multiple;
% plot3(x_edge, y_edge, z_edge,'color','r', 'LineWidth', 2);


end

