function [A_out, b_out] = my_linearconstraints(z0,N,N_hat,n_star,N_all,h_tighten,boxCR)
g=evalin('base','g');
Phi=evalin('base','Phi');
B=evalin('base','B');
h=evalin('base','h');
A=zeros(N,size(Phi,1));
A_final=zeros(N_hat,size(Phi,1));
b=zeros(N,1);
b_final= zeros(N_hat,1);
for i=1:1:N
    for j=1:1:i
        A(i,j)=g'*Phi^(i-j)*B;
    end
    b(i)=h-h_tighten(i)-g'*Phi^(i)*z0;
end
%终端约束部分
%下面这段是对zN的约束
for r = 1:1:N_hat
    A_final(r,:)=g'*Phi^(r);
    b_final(r)=h-h_tighten(N+r);
end
%从终端约束里找个max鲁棒正不变集出来
Xf_before= Polyhedron('A',A_final,'b',b_final);
Xf_after = compute_MAXRPI(Phi,boxCR,Xf_before);
Xf_after
% 此时Xf_after是对zN的约束，还要转化为对v0~vN-1的
trans = [];
for i = 1:1:N
    trans = [trans,Phi^(N-i)*B];
end
A_tilde = Xf_after.A*trans;
b_tilde = Xf_after.b-Xf_after.A*Phi^N*z0;
A_out=[A;A_tilde];
b_out=[b;b_tilde];
%n_star部分先不写吧，Cannon那个例子里也设的n_star是0
% for i = 1:1:n_star
% 
% end


