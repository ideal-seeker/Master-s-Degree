clear;
clc;

i=0;
T_all=[];
while i<100

objfun = @(x) x(1)^2 + x(2)^2;

beta = 1e1;
x0 = [0.5, 0.5]*beta;

lb = [0, 0];
ub = [100, 100]*beta;
%优化问题求解部分
options = optimset('Algorithm','sqp');
tic
[x, fval, exitflag, output] = fmincon(objfun, x0, [], [], [], [], lb, ub, [], options);
T1=toc;

T_all=[T_all,T1];
i=i+1;
end
T_mean = mean(T_all)