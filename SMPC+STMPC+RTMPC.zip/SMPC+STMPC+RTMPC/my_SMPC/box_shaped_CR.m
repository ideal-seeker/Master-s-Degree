function box_region = box_shaped_CR(Sigma,p)
[n,~]=size(Sigma);
p_divide = (1-p)/n;
A=zeros(2*n,n);
b=[];
for i = 1:1:n
    A(2*i-1:2*i,i) =[1;-1];
    b = [b;Sigma(i,i)/p_divide;Sigma(i,i)/p_divide];
end
box_region=Polyhedron('A',A,'b',b);
end

