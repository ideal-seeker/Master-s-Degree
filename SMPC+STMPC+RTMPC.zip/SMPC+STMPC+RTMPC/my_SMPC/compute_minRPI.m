function [it,Fs] = compute_minRPI(Phi, W,epsilon)
            % Computes an invariant approximation of the minimal robust positively
            % invariant set for 
            % x^{+} = Ax + w with w \in W
            % according to Algorithm 1 in 'Invariant approximations of
            % the minimal robust positively invariant set' by Rakovic et al. 
            % Requires a matrix A, a Polytope W, and a tolerance 'epsilon'.  
            [nx,~] = size(Phi); 
            s = 0; 
            alpha = 1000;
            Ms = 1000;
            E = eye(nx);
            it = 0;
            while(alpha > epsilon/(epsilon + Ms)&&it<100)
                s = s+1;
                alpha = max(W.support(Phi^s*(W.A)')./W.b);
                mss = zeros(2*nx,1);
                for i = 1:s
                    mss = mss+W.support([Phi^i, -Phi^i]);
                end
                Ms = max(mss);
                it = it+1;
            end
            Fs = W;
              figure(10)
              plot(Fs)
            for i =1:s-1
                Fs = Fs+Phi^i*W;
                figure(i+20)
                plot(Fs)
            end

            Fs = (1/(1-alpha))*Fs;
                figure(11)
                plot(Fs)
 end


