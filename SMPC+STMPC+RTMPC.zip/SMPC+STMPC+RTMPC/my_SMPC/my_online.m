% 在线部分要做的事
% 初始化初始点
x_after=[2;3];%每一时刻的初始状态（已知）
u_0=zeros(N,1);
% 初始化扰动值
w=0;
% 循环求解结构
mpciter=1;%表示当前时刻
mpciterations=10;%总循环次数
%统计
%初始化预设概率
Sigma_N=Phi^(N)*w_cov*(Phi^(N))';
count_of_constraint=0;
exitflags=zeros(1,mpciterations);
z_afters=zeros(2,mpciterations);
x_afters=zeros(2,mpciterations);
u_s=zeros(1,mpciterations);
% constraint_final_Poly = box_bound(p,Sigma_N,2);
boxCR=box_shaped_CR(Sigma_N,p_ref);%终端约束收紧成概率不变集所用的置信域
while(mpciter <= mpciterations)

    %更改初始值
    x_before = x_after;
    %构造MPC问题:约束
    [A_cons,b_cons] = my_linearconstraints(x_before,N,N_hat,n_star,N_all,h_tighten,boxCR);
    lb = -0.5*ones(size(u_0,1),1);
    ub = 0.5*ones(size(u_0,1),1);
    %构造MPC问题:代价函数.
    %求解MPC问题
    options = optimset('Algorithm','sqp');
    [u_long, ~, exitflag, output] = ...
    fmincon(@(u) my_costfunction(N,x_before,u,K,A,B),...
    u_0,A_cons,b_cons,[],[],[],[],[],options);
    %取第一个解
    u_after=u_long(1);
    %扰动取值
    w=mvnrnd(w_mean,w_cov)';
    %解和扰动代入系统里
    z_after = Phi*x_before+B*u_after;
    x_after = Phi*x_before+B*u_after+w;
    %统计控制效果
    z_afters(:,mpciter)=g'*z_after-h+h_tighten(1);
    x_afters(:,mpciter)=g'*x_after-h;
    u_s(mpciter) = u_after;
    exitflags(mpciter)=exitflag;
    % 可行性：
    %优化问题下约束是否是起作用约束
    % 约束概率满足统计
    if g'*x_after<=h
         count_of_constraint=count_of_constraint+1;
    end
    mpciter=mpciter+1;
    plot(x_before(1),x_before(2),'-o');
    hold on
end
% 画图
%画可行域（先只画x1|k,即对v0的）,w用box置信域要不另外两个算法用不了

offandon;