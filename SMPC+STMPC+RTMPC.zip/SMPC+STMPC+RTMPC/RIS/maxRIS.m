% addpath('../src/')
% addpath('../src/utils/')\
%% minimal RIS
%system initial
%2011 Example 1
A = [0.8916 0.1225;-0.1225 0.8916];
B = [0;0]; 
Phi = A;%非自治系统这里要有个LQR算Phi
% [K,~,~] = dlqr(A,B,Q,R,N);
% Phi=A-B*K;
Q = diag([1, 1]);
R = 0.1;
W_vertex = [0.01, 0.01; 0.01, -0.01; -0.01, -0.01; -0.01, 0.01]; % construct a convex set of disturbance (2dim here)
W = Polyhedron(W_vertex);
epsilon=0.05;
% F_inf是最小正不变集
[r,F_inf] = compute_mRPI(Phi,W,epsilon);
%% maximum RIS
Xc_vertex = [100, -20; 100 100; -100 100; -100 -20];
Uc_vertex = [1; -1];
Xc = Polyhedron(Xc_vertex);
Hx=Xc.A;
Kx=Xc.b;
Uc = Polyhedron(Uc_vertex);
X1=Xc-F_inf;%这应该直接就是闵可夫斯基差（还是叫庞特里亚金差）
% plot(X1)
oldVertices = X1.V;
s = 0;
mark=0;
%首先求满足条件的s
while (mark~=1)
    s=s+1;
    oldVertices=(Phi*oldVertices')';
    AsX1 = Polyhedron(oldVertices);
    mark = X1.contains(Phi^s*X1);
end
%之后求Ks
J_Ks_cell=cell(s,s);
for row=1:1:s
    for col = 1:1:s
        if row<=col
            J_Ks_cell{row,col}=zeros(size(Xc.A));
        else
            J_Ks_cell{row,col}=Xc.A*Phi^(row-col-1);
        end
    end
end
J_Ks = cell2mat(J_Ks_cell);
w0 = zeros(s*W.Dim,1);
options = optimset('Algorithm','sqp');
num=1;
A_cons=W.A;
while num<s
    num=num+1;
    A_cons=blkdiag(A_cons,W.A);
end
    b_cons = repmat(W.b,s,1);
    %s个线性规划问题
Ks=[];
for k=1:1:s
    fun = @(w) -J_Ks(k,:)*w;
    [x, fval, exitflag, output] = fmincon(fun, w0,  A_cons, b_cons,[], [], [], [], [], options);
    Ks=[Ks;fval];
end
O_infty_A=Hx;
for i = 1:1:s-1
    O_infty_A=[O_infty_A;Hx*Phi^i];
end
O_infty_b=repmat(Kx,s,1);
O_infty = Polyhedron('A',O_infty_A,'b',O_infty_b);
plot(O_infty);