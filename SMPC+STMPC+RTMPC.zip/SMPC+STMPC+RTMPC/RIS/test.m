% P1=Polyhedron([2,1;1,-1;-1,1;-1,-2]);
% P2=Polyhedron([1,1;1,-1;-1,1;-1,-2])*0.4;
% plot(P1);
% plot(P2);
% figure(1)
% plot(P1);
% figure(2)
% plot(P2)
% figure(3);
% plot(P1-P2)
% I = P1.contains(P1-P2)
% P3=Polyhedron([1,-1;1,1;-1,1;-1,-1]);
% plot(P3)
CC=cell(2,2);
CC{1,1}=zeros(2);
CC{1,2}=zeros(2);CC{2,1}=zeros(2);
CC{2,2}=[1,2;3,4];
RE = cell2mat(CC)

