clear
clc
lambda = 0.41;
A = [1.8 -0.5;-1.5 1.2];
B_u = [2;1];
B_w = eye(2);
W = eye(2);
g = [-1.75 1]';
h = 1.5;
Q = eye(2);
R = 5;
[K,fai] = compute_of_K(A, B_u,Q,R);
    V_inv = sdpvar(size(B_w,1),size(B_w,1),'symmetric');
    c =[V_inv-(1/lambda)*fai*V_inv*fai'-B_w*inv(W)*B_w'>=0];
    obj = (g'*V_inv*g)/(1-lambda); %该问题的目标函数
    constraints = [c,V_inv>=0,obj];%问题约束
    optimize(constraints,obj);
    invV = value(V_inv);
    oobbjj = value(obj);
