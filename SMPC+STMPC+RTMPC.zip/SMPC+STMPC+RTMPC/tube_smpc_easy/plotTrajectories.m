function plotTrajectories(T, t0, x0, u, type)%���켣
plot_pause=evalin('base','plot_pause');
B_u=evalin('base','B_u');
x1_limit = 0;
% x0
[x, t_intermediate, x_intermediate] = dynamic( T, t0, x0, u ,type, 0, 0);%�����⣬Ӧ�������һ��u��
% x
u;
% x_intermediate
x_intermediate_new=reshape(x_intermediate,size(x0,1),size(x_intermediate,1)/size(x0,1));
% x_intermediate_new
% set up figure
figure(1);
title('x_1/x_2 trajectory');
xlabel('x_1');
ylabel('x_2');
%         title('$x_1$/$x_2$ trajectory','Interpreter','Latex');
%         xlabel('$x_1$','Interpreter','Latex');
%         ylabel('$x_2$','Interpreter','Latex');
grid on;%��������
hold on;%����һ��ͼʱ��������ͼ��

% initial plot details
if t0 == 0
    % x1 - limit

    h1=xline(x1_limit);%��x1_limit����һ������
    h2=fill([x1_limit x1_limit x1_limit+100 x1_limit+100],[-1000 1000 1000 -1000],'black','FaceColor',[1 1 0],'FaceAlpha',0.1,'LineStyle','none');%������򣬺�������������Ӧ��black��ɶ��
    set(get(get(h1,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
    set(get(get(h2,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');

    % start
    %�ʼ�ĵ�
    h3 = plot(x_intermediate_new(1,1),x_intermediate_new(2,1),'ob','MarkerSize',10, 'linewidth',0.6);%�Ǹ�ob�ǵ��Ͱ�
    set(get(get(h3,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
    % target point
    h4 = plot(0,0,'kx','MarkerSize',12, 'linewidth',2);%kxӦ��Ҳ�ǵ������֣�Ŀ���
    set(get(get(h4,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
end

% trajectory: �켣
% - blue: current real position
% - red: planned next position with optimized input
% - orange: planned trajectory������
%�̶��ģ�����ʱ���
hc = plot(x_intermediate_new(1,:),x_intermediate_new(2,:),'r:','Linewidth',0.6);         % connection current state to next predicted state
set(get(get(hc,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
hb = plot(x_intermediate_new(1,1),x_intermediate_new(2,1),'ob', ...     % current state,x0
    'MarkerFaceColor','b','MarkerSize',6);
hr = plot(x_intermediate_new(1,2),x_intermediate_new(2,2),'or', ...     % next predicted state,����u_new֮�������ϵ���һ�����������w
    'MarkerFaceColor','r');
%         axis([-2.5 6.0 -2 6.5]*10);
axis([-2.5 6.0 -2 6.5]*10);
axis square;
%         axis equal;
%         if params(3) == 0 % (no MPC, mpc_mode==0)
%             axis([-2.5 12.0 -2 6.5]); % if u==0 --> system moves farther in x1-direction
%             axis equal;
%         end

% mark positions with constraint violation
% if x_intermediate_new(1,1) > x1_limit +0.000001  % account for numerical uncertainty
%     he = plot(x_intermediate_new(1,1),x_intermediate_new(1,2),'ow','MarkerSize',3, 'MarkerFaceColor','w');
%     set(get(get(he,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
% end


% show prediction
x_pred = zeros(length(x),length(u));
x_pred(:,1) = x0;
for i = 2:length(u)/size(B_u,2)
    x_pred(:,i) = systemiterate(0, x_pred(:,i-1), u(size(B_u,2)*(i-2)+1:size(B_u,2)*(i-1),1), T, 0, 0);
end
hm = plot(x_pred(1,:),x_pred(2,:),'m*-','Linewidth',0.5, 'Markersize', 7, 'Color', [1,0.4,0]);

% legend (only once)
if t0 == 0
    legend([hb,hr,hm],{'real state','next predicted step','prediction'},'Location','northwest', 'FontSize',10,'AutoUpdate','off')

end

% pause if necessary
pause(plot_pause)


% delete predicted inputs
children = get(gca, 'children');
delete(children(1));
delete(hm);



end