A = [1.8 -0.5;-1.5 1.2];
B_u = [2;1];
B_w = eye(2);
W = eye(2);
%约束：
g = [-1.75 1]';
h = 1.5;
g=[-1.75 1]';
lambda = 0.41;
Q = [1 0;0 1];
R = 5;
[K,fai] = compute_of_K(A, B_u,Q,R);
% 使用 cvx 工具箱解决 SDP 问题
cvx_begin sdp
    variable V_inv(2, 2) symmetric % 对称半正定矩阵变量
    minimize((g'*V_inv*g)/(1-lambda)) % 目标函数
    subject to
        V_inv >= 0 % X 是半正定矩阵
    subject to
        V_inv-(1/lambda)*fai*V_inv*fai'-B_w*inv(W)*B_w'>=0
cvx_end

% 显示结果
% disp(cvx().status);
disp(V_inv);
disp(['Optimal value of the objective function: ' num2str((g'*V_inv*g)/(1-lambda))]);
