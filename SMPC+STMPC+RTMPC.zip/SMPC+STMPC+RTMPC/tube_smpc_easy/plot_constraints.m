% P_b = Polyhedron('A',g','b',h);
% 
% p_a_1 = Polyhedron('A',g','b',cun_f(1));
% p_a_13 = Polyhedron('A',g','b',cun_f(13));
% P_b.plot();
% hold on;
% p_a_1.plot()
% hold on
% p_a_13.plot()
% legend('before','after1','after13');
% hold on 
% % fplot(@(x) x'*inv(V_inv)*x-b_bars(1));
% 
a = [];
for i = 1:1:13
    a = [a,alpha_bar/(1-lambda)*(1-lambda^i)];
end
disp(a);