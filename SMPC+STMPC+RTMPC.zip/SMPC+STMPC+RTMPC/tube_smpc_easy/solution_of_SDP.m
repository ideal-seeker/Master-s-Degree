function [V_inv_final,lambda_final,option_final,result_solved_options] = solution_of_SDP(B_w,fai,g,W,lambda_sequence)
%��Ϊֻ��һ��fai���ֻ��һ��ѭ��
long = length(lambda_sequence);
option = zeros(1,long);
option_all = [];
V_inv_all = [];
lambda_all = [];
n = size(B_w,1);
inv_W = inv(W);

result_solved_options = [];
result_solved_V_inv = [];
result_solved_num = [];
    for e = 1:1:long
        cvx_begin sdp
        variable V_inv(n, n) symmetric % �Գư������������
        minimize((g'*V_inv*g)/(1-lambda_sequence(e))) % Ŀ�꺯��
        subject to
        V_inv >= 0; % X �ǰ���������
        V_inv-(1/lambda_sequence(e))*fai*V_inv*fai'-B_w*inv_W*B_w' >= 0
        cvx_end
        option = (g'*V_inv*g)/(1-lambda_sequence(e));
        if strcmp(cvx_status, 'Solved')
            result_solved_options = [result_solved_options,option];
            result_solved_V_inv = [result_solved_V_inv,V_inv];
            result_solved_num = [result_solved_num,e];
        end
    end
    if(isempty(result_solved_V_inv))
        error('SDP�����޽⣬����ֹͣ');
    else
        [option_final,nums] = min(result_solved_options);
        V_inv_final = result_solved_V_inv(:,n*(nums-1)+1:n*nums);
        number = result_solved_num(nums);
        lambda_final = lambda_sequence(number);
    end



end