clear;
clc;
%论文中的例子，用于测试离线部分是否正确
N=6;
N_hat=7;
Nc = 1;
n_star = 0;
%系统参数
A = [1.8 -0.5;-1.5 1.2];
B_u = [2;1];
B_w = eye(2);
W = eye(2);
%约束：
g = [-1.75 1]';
h = 1.5;
p = 1;%满足约束的概率

%不确定量
alpha_bar =0.1 ;
%rho
rho = 1000;%改
%MPC参数
Q = [1 0;0 1];
R = 5;
[K,fai] = compute_of_K(A, B_u,Q,R);
tic
delta_lambda = 1/100;
lambda_sequence = 0.15:delta_lambda:1-delta_lambda;%改
[V_inv,lambda,option,options,invs] = easy_solution_of_SDP(B_w,fai,g,W,lambda_sequence,alpha_bar,h);%改，invV要有个选的
toc;
disp(['半定规划时间：',num2str(toc)])
% % 计算Π
tic;
beta_bar = alpha_bar/(1-lambda);
%这之前是对的
%建立两个函数分布
%alpha
%w
beta0 = 0;
F_beta0 =ones(rho+1,1);

[pi_i_0,P,Inte,row_X]=compute_of_pi(lambda,F_beta0,rho,N+N_hat,beta_bar);
pi = ones(rho+1,N+N_hat,N+N_hat);
mid = zeros(N+N_hat,1);
for k = 1:1:N+N_hat+1
    if k==1
        pi(:,:,k)=pi_i_0;
    else
        for j = 1:1:N+N_hat+1%1是(xk|k)0时刻！！！
            if j<k
                pi(:,j,k)=0;%k时刻对j时刻的预测
            elseif j==k
                % middle = ind_function(pi(:,j,1),1,rho);
                % middle=ceil((1-lambda^(j-1))*rho);
                middle = ind_function(pi,1,rho);%改
                mid(k) =  middle;
                pi(:,j,k) = [zeros(1,middle-1),ones(1,rho+1-middle+1)]';
            elseif j>k
                pi(:,j,k) = P*pi(:,j-1,k)+Inte;%三维的时候最后一个维度是时间轴，前两个是行和列
            end
        end
    end
end

b_bars = b_bar(pi,p,row_X,N+N_hat,rho);

toc;
disp(['求概率椭圆运行时间: ',num2str(toc)])

