function [x, t_intermediate, x_intermediate] = dynamic(T,mpciter,k,t0,x0,u,apply_flag)
    x = systemiterate(mpciter,k,x0,u,apply_flag);
    x_intermediate = [x0; x];
    t_intermediate = [t0, t0+T];

end