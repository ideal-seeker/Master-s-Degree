function [tapplied, xapplied] = applyControl_of_z( mpciter,T, t0, x0, u)
BK_tilde=evalin('base','BK_tilde');
    %����״̬�͵�ǰʱ��ĺ���
    apply_flag = 0; % for prediction, no noise is applied (=0); for actual system noise is applied (=1)
    % xapplied = dynamic(mpciter,1,T, t0, x0,u(1:size(B_u,2),1),type, apply_flag);
    xapplied = dynamic(T,mpciter,1, t0, x0, u(1:size(BK_tilde,2),1),apply_flag);
    tapplied = t0+T;
end