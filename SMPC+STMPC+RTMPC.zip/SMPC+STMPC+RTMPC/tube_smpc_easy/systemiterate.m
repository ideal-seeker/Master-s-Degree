function x_now = systemiterate(mpciter,kk, x, u, apply_flag)
% apply_flag: 1) noise is applied for real system; 0) no noise for prediction
AK_tilde = evalin('base', 'AK_tilde');
K = evalin('base', 'K');
BK_tilde=evalin('base','BK_tilde');
B_w=evalin('base','B_w');
alpha_bar = evalin('base','alpha_bar');
count_ref = evalin('base','count_ref');
A = AK_tilde(:,:,mod(mpciter+kk-1,count_ref)+1);
B_u = BK_tilde(:,:,mod(mpciter+kk-1,count_ref)+1);
x_now = A*x+B_u*(u(1:size(B_u,2),1) + K(:,:,mod(mpciter+kk-1,count_ref)+1)*x);%！%这个K???

if apply_flag == 1
    w_mean = 0;
    w_sigma = 1/12;  
    alpha_k=alpha_get(alpha_bar);
    %产生符合w分布w_produce的随机数
    w =w_get(alpha_k,w_mean,w_sigma);%有时间 改个名字
    x_now = x_now + B_w*w;

end
end