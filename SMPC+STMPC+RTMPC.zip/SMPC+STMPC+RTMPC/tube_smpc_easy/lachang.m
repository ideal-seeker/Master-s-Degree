function M_new = lachang(M,num)
%LACHANG 此处显示有关此函数的摘要
%   此处显示详细说明
count_3 = size(M,3);
for i = count3+1:1:num
    M_new(:,:,i)=
end
end

