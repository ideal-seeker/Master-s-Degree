function [p] = f_alpha(x)
%概率界alpha_k的概率分布函数
alpha_bar = evalin('base','alpha_bar');
alpha_hat = alpha_bar/2;
col = size(x,2);
if col==1
    if x<=0
        p=0;
    elseif x<=alpha_hat
        p=x/alpha_hat^2;
    elseif x<= alpha_bar
        p = 2/alpha_hat-x/alpha_hat^2;
    else
        p=0;
    end

elseif col>1
    p = zeros(size(x));
    for i = 1:1:col
        if x(i)<=0
            p(i)=0;
        elseif x(i)<=alpha_hat
            p(i)=x(i)/alpha_hat^2;
        elseif x(i)<= alpha_bar
            p(i) = 2/alpha_hat-x(i)/alpha_hat^2;
        else
            p(i)=0;
        end

    end
end

end

