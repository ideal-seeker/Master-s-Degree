function cost = costfunction_2(mpciter,N,N_hat, x0, u,K,A,B)%这个是用作方程的，u是参数，用的时候还不确定是几

Q = evalin('base','Q');
R = evalin('base','R');
m = size(B,2);
n = size(A,1);
x = [x0,zeros(n,N-1)];
%预测时域是N+N_hat吧,但是c只有N个
E = [eye(m),zeros(m,m*(N-1))];
M = zeros((N)*m,(N)*m);
for i = 1:1:N-1
    x(i+1) = A*x(i)+
end
for i = 1:1:N-1
    M(i,(1+(i-1))*m+1:(1+i)*m)=ones(1,m);
end
cha0 = [A+B*K,B*E;zeros(size(M,1),size(A+B*K,2)),M];
d_hat = 1;
Q_tilde = [ Q+K'*R*K,K'*R*E;E'*R*K,E'*R*E];
P11 = dlyap(cha0',Q_tilde);
d_blank = [d_hat;zeros(size(P11,1)-1,1)];
thetaa = dlyap(cha0, d_blank*d_blank'); % 一般令Q=I（I指单位阵
P12 = zeros(n+m*(N),1);
P13 = zeros(n+m*(N),1)';
P14 = trace(thetaa*P11);
cost = [x0;u;1]'*[P11,P12;P13,P14]*[x0;u;1];
