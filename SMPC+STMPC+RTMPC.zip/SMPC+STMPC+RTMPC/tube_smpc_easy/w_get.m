function w = w_get(alpha_k,w_mean,w_cov,w_low,w_up)
%W_TRUNCATE 此处显示有关此函数的摘要
B_w = evalin('base','B_w');
W = evalin('base','W');
n = size(B_w,2);
w = [10;10];%随便取一个一定满足w'Ww>alpha_k的值
%两个一维正态分布垒成二维的，因为从协方差看是独立的。
pd_normal_1 = makedist('Normal','mu',w_mean,'sigma',w_cov(1,1));%当a=n/2,β=1/2时，伽马分布为自由度为n的卡方分布
pd_normal_2 = makedist('Normal','mu',w_mean,'sigma',w_cov(2,2));
sq_alpha_k = sqrt(alpha_k);
w_low = max(w_low,-sq_alpha_k);
w_up = min(w_up,sq_alpha_k);
w_truncate_distribution_1 = truncate(pd_normal_1,w_low,w_up);
w_truncate_distribution_2 = truncate(pd_normal_2,w_low,w_up);
while w'*W*w>alpha_k
  w_1 = random(w_truncate_distribution_1);
  w_2 = random(w_truncate_distribution_2);
  w = [w_1;w_2];
end
end 

