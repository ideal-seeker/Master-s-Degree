function [t0, x0] = measureInitialValue ( tmeasure, xmeasure )
%���³�ʼ��
    t0 = tmeasure;
    x0 = xmeasure;
end
