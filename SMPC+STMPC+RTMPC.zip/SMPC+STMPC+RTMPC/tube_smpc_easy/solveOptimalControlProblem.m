function [yueshu_f,cun_f,uend, exitflag, output] = solveOptimalControlProblem(mpciter,N,N_hat,x0,u0,n_star)
h = evalin('base','h');
g = evalin('base','g');
% V = evalin('base','V');
K = evalin('base','K');
A = evalin('base','A');
B_u = evalin('base','B_u');
% x = zeros((N+1)*size(x0,1),size(x0,2));
% x = computeOpenloopSolution(T,mpciter,N,N_hat,t0,x0,u0);
cun_f =[];
a = [];
b = [];
Aeq = [];
beq = [];
lb = [];
ub = [];
bout=[];
au = [];
bbbb=[];
yueshu_f = [];
for i=1:1:N+N_hat+n_star
    [yueshu,cun,Anew, bnew, Aeqnew, beqnew] = linearconstraints(i,x0,N,N_hat);%u0�ǳ��ִ����ʱ������ֵ
    a = [a;Anew];
    b = [b;bnew];
    Aeq = [Aeq,Aeqnew];
    beq = [beq, beqnew];
    % lb = [lb; lbnew];
    % ub = [ub; ubnew];
    cun_f=[cun_f;cun];
    yueshu_f = [yueshu_f;yueshu];
end
a=full(a);
b = full(b);
% a
% b
Aeq=full(Aeq);
beq = full(beq);

lb = -0.5*ones(size(u0,1),1);
ub = 0.5*ones(size(u0,1),1);
options = optimset('Algorithm','sqp');
[u, ~, exitflag, output] = fmincon(@(u) costfunction(N,x0,u,K,A,B_u),...
    u0,a,b,Aeq,beq,[],[],[],options);
uend=u;
% bout=[bout,(b-A*uend)./b];
% au = [au,A*uend];
% m = A*uend;
% bbbb = [bbbb,(h-m(1)/(sqrt(g'*inv(V(:,:,mpciter+1))*g)))^2];
end