function cost = terminalcosts(t, x)
    cost = 0.0;
end