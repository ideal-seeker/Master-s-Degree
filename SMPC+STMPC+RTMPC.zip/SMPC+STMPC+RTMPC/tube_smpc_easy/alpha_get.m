function alpha_k = alpha_get(alpha_bar,ziyoudu)
%ALPHA_GET 此处显示有关此函数的摘要
%   此处显示详细说明
A = evalin('base','A');
n = size(A,1);

pd_gama = makedist('Gamma','a',ziyoudu/2,'b',1/2);%当a=n/2,β=1/2时，伽马分布为自由度为n的卡方分布
t = truncate(pd_gama,0,alpha_bar);
alpha_k =random(t);
end

