function [invV,lambda_final,option_final,options,invs] = easy_solution_of_SDP(B_w,fai,g,W,lambda_sequence,alpha_bar,h)
long = length(lambda_sequence);
options = zeros(1,length(lambda_sequence));
invs = zeros(2,2,length(lambda_sequence));
for e = 1:1:long
    c=[];
    V_inv = sdpvar(size(B_w,1),size(B_w,1),'symmetric');
    c =[V_inv-(1/lambda_sequence(e))*fai*V_inv*fai'-B_w*inv(W)*B_w'>=0,V_inv>=0];
    obj = (g'*V_inv*g)/(1-lambda_sequence(e)); %该问题的目标函数
    constraints = [c,obj];%问题约束
    optimize(constraints,obj);
    invV = value(V_inv);
    options(e) = (g'*invV*g)/(1-lambda_sequence(e));
    invs(:,:,e) = invV;
end
[option_final,number] = min(options);
lambda_final = lambda_sequence(number);
invV = invs(:,:,number);
end
