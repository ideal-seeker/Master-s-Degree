B_u=B;
B_w = eye(2);
W=eye(2);

%约束：

%不确定量
alpha_bar = 0.1 ;
ziyoudu_alpha = 3;
%rho
rho = 600 ;%改
%MPC参数
%LQR求得到反馈系数
[K,fai] = compute_of_K(A, B_u,Q,R);

tic
delta_lambda = 1/100;
lambda_sequence = delta_lambda:delta_lambda:1-delta_lambda;
[V_inv,lambda,option] = solution_of_SDP(B_w,fai,g,W,lambda_sequence);
toc;
disp(['半定规划时间：',num2str(toc)])
% % 计算Π
tic;
%半定规划部分改好了

%b的计算还有问题，先截断二维高斯分布
beta_bar = alpha_bar/(1-lambda);
beta0 = 0;
F_beta0 =[1;ones(rho,1)];

% pd_gama = makedist('Gamma','a',size(A,2)/2,'b',1/2);%当a=n/2,β=1/2时，伽马分布为自由度为n的卡方分布
pd_gama = makedist('Gamma','a',ziyoudu_alpha/2,'b',1/2);%当a=n/2,β=1/2时，伽马分布为自由度为n的卡方分布
alpha_truncate_distribution = truncate(pd_gama,0,alpha_bar);

[pi_i_0,P,Inte,row_X]=compute_of_pi(lambda,F_beta0,rho,N+N_hat+1,beta_bar,alpha_truncate_distribution);
pi_all = ones(rho+1,N+N_hat+1,N+N_hat+1);
mid = zeros(N+N_hat,1);
for k = 1:1:N+N_hat+1
    if k==1
        pi_all(:,:,k)=pi_i_0;
    else
        for j = 1:1:N+N_hat+1
            if j<k
                pi_all(:,j,k)=0;%k时刻对j时刻的预测
            elseif j==k
                % middle = ind_function(pi(:,j,1),1,rho);
                % middle=ceil((1-lambda^j)*rho);
                middle = ind_function(pi_i_0(:,j),1,rho);
                mid(k) =  middle;
                pi_all(:,j,k) = [zeros(1,middle-1),ones(1,rho+1-middle+1)]';
            elseif j>k
                pi_all(:,j,k) = P*pi_all(:,j-1,k)+Inte;%三维的时候最后一个维度是时间轴，前两个是行和列
            end
        end
    end
end
toc;
disp(['求概率椭圆运行时间: ',num2str(toc)])

%online
V = inv(V_inv);
w_mean=0;
w_low = -2.68;
w_up = 2.68;
erfen_time = 0;
p_need=0.6;
p_head = 0.5;
p_tail = 1;
pr_count_of_constraint_before = 100;%第一次
[b_bars,b_bar_all] = b_bar(pi_all,p_ref,row_X,N+N_hat,rho);
AA=g';
bb=h-sqrt(b_bars(1))*sqrt(g'*V_inv*g);

