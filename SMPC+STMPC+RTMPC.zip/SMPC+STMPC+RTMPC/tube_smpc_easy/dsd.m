alpha_bar = 0.1;
% fun = @f_alpha;
 fun = @w_produce;
fi = zeros(size(1:1:50));
for i = 1:1:50
    fi(i) = fun((i-25)/100,sqrt(0.04));
% fi(i) = fun((i-25)/100);
end
figure
plot((1-25:1:50-25)*0.01,fi)
% y = integral(fun(x,0.005),-Inf,Inf,'ArrayValued',true)
