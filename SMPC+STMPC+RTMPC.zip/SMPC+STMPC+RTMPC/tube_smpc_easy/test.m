% clear;
% clc;
% %参考轨迹
% % 定义圆形的半径
% r = 3;
% 
% % 创建一个由角度值组成的向量
% theta = linspace(0,2*pi,100);
% phi_ref = theta+pi/2;
% % 将极坐标转换为笛卡尔坐标
% x = r * cos(theta);
% y = r * sin(theta);
% 
% % 绘制圆形轨迹
% plot(x, y, '-o');  % 在圆周上显示离散点
% axis ([-4,4,-4,4]);  % 设置坐标轴比例相等，使圆形看起来更圆
a = repmat([1,2,3,4,5],1,3);
b = diag(a)
