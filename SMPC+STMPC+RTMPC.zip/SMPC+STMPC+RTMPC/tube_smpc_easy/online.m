%%%在线计算MPC部分,采用双模控制
%初始化
T1=tic;
Nc = evalin('base','Nc');
N = evalin('base','N');
N_hat = evalin('base','N_hat');
n_star = 0;
V = inv(V_inv);
w_mean=0;
w_cov=diag([0.02,0.04]);
w_low = -2.68;
w_up = 2.68;
erfen_time = 0;
p_need=0.6;
p_head = 0.5;
p_tail = 1;
pr_count_of_constraint_before = 100;%第一次
% p=0.5033;
% p=1.0;%测试用，如果收敛于0.1695即和论文理论一样.结果：收敛于0.1647，大差不差
while ((pr_count_of_constraint_before == 100 || (pr_count_of_constraint_before >= (p_need*100+10)) || (pr_count_of_constraint_before <= (p_need*100-10)))&& erfen_time<=0)
    erfen_time = erfen_time+1;
    if erfen_time ~= 1
        if (pr_count_of_constraint_before >= (p*100+10))
            p_tail = p;
            p = 0.5*(p+p_head);
        elseif (pr_count_of_constraint_before <= (p*100-10))
            p_head = p;
            p = 0.5*(p+tail);
        end
    else
        p = p_need;
    end
    [b_bars,b_bar_all] = b_bar(pi_all,p,row_X,N+N_hat,rho);
    % b_bars = [0.31,4.41,6.09,6.78,7.06,7.18,7.19,7.20,7.26,7.26,7.26,7.26,7.26]*1e-2;
    AA=g';
    bb=h-sqrt(b_bars(1))*sqrt(g'*V_inv*g);
        feasible_region_stmpc=Polyhedron('A',AA,'b',bb);
    figure(8)

    plot(feasible_region_stmpc);
    text(feasible_region_stmpc.V(1),feasible_region_stmpc.V(2),'STMPC',Color='b');
    text(feasible_region_origin.V(1)-0.2,feasible_region_origin.V(2)-0.4,'feasible_region',Color='b');
    iprint=10;
    % T = 0.1;
    u0 = 0.01*ones((N)*size(B_u,2),1);
    % tmeasure=0;
    x_measure=[0.4; 0.5];
    mpciterations=300;%迭代次数
    mpciter = 0;%初始次数为0,统计迭代次数
    plot_pause   = 0;
    t = [];
    x = [];
    u = [];
    b_out=[];
    au = [];
    bbbb=[];
    cun_all = [];
    yueshu_all = [];

    count_of_constraint=0;
    comp_time=[];
    jianyanyueshu = [];
    jianyanyueshu_w = [];
    chunchun_w = [];
    x_jilu = zeros(size(fai,1),mpciterations+1);
    z_jilu =  [x_measure,zeros(size(fai,1),mpciterations)];
    w_jilu = [];
    alpha_jilu = [];
    % x_yuce = zeros(5,mpciterations+1);
    w_in_elliptical= [];
    e_in_elliptical = [];
    e_in_prob_elliptical = [];
    flag =[];
    while(mpciter < mpciterations)

        x0 = x_measure;%更新初始点 x_measure是实际为位置
        % x_r = [x_ref(mod(mpciter,count_ref)+1);y_ref(mod(mpciter,count_ref)+1);phi_ref(mod(mpciter,count_ref)+1);w_ref;v_ref];%因为是匀速直线所以线速度和角速度不变
        % kexi = x0-x_r;%这个是往状态空间方程里代入的位置误差
        % x0 = kexi;%!!作为优化问题的x0，是误差值

        % t_Start = tic;%内置计时

        [yueshu_f,cun_f,u_new, exitflag, output] = solveOptimalControlProblem(mpciter,N,N_hat,x0,u0,n_star);
        cun_all = [cun_all,cun_f];
        yueshu_all = [yueshu_all,yueshu_f];
        flag =[flag,exitflag];%观察优化问题是否有解，-2是没有

        u = [ u, u_new(1:size(B_u,2),1)];%只拿第一个
        u0 = shiftHorizon(u_new);
        x_jilu(:,mpciter+1)=x_measure;
        z_jilu0 = fai*x0+B_u*u_new(1:size(B_u,2),1);
        %扰动取值
        alpha_k=alpha_get(alpha_bar,ziyoudu_alpha);

        w =w_get(alpha_k,w_mean,w_cov,w_low,w_up);

        x_measure = z_jilu0+B_w*w;

        if g'*x_measure<=h% 因为h是一维所以就暂时这么写了,且因为约束收紧的就是关于跟踪误差系统的约束，因此这里也要用误差来测试,
            % 这里可以把无解的地方去掉？但是根据迭代可行性初始有解后面应该都有解阿。。n*的问题？
            count_of_constraint=count_of_constraint+1;
        end

        z_jilu(:,mpciter+2)=z_jilu0;
        alpha_jilu = [alpha_jilu,alpha_k];
        w_jilu = [w_jilu,w];
        mpciter = mpciter+1;
        w_in_elliptical =[w_in_elliptical,alpha_k- w'*W*w];
        e_in_elliptical = [e_in_elliptical,alpha_k- w'*V*w];
        e_in_prob_elliptical = [e_in_prob_elliptical,b_bars(1)- w'*V*w];

    end
    pr_count_of_constraint_before = count_of_constraint/mpciterations*100;
end
fprintf('设定约束被满足的概率为%f%%\n',p_need*100);
fprintf('加了松弛变量之后的对应概率为%f%%\n',p*100);
% fprintf('对应2p-1概率为%f%%\n',(2*p-1)*100);
fprintf('约束被满足的概率为%f%%\n  ',pr_count_of_constraint_before);
figure(1)
plot(x_jilu(1,:),x_jilu(2,:),'-r');  % 在圆周上显示离散点
T2 = toc(T1 );
disp(['在线运行平均总时间为:',num2str(T2/mpciterations)]);


% %draw
% figure (2)
% plot(w_jilu(1,:),w_jilu(2,:),'+')
% hold on
% 
% r = sqrt(alpha_bar);%半径
% a = 0;%横坐标
% b = 0;%纵坐标
% 
% para = [a-r, b-r, 2*r, 2*r];
% rectangle('Position', para, 'Curvature', [1 1]);
% 
% %tuoyuan
% A_tuoyuan = V(1,1);
% B_tuoyuan = V(1,2)+V(2,1);
% C_tuoyuan = V(2,2);
% D_tuoyuan = 0;
% E_tuoyuan = 0;
% F =-b_bars(1);
% aa = 2/(A_tuoyuan+C_tuoyuan-sqrt(B_tuoyuan^2+(A_tuoyuan-C_tuoyuan).^2));
% bb = 2/(A_tuoyuan+C_tuoyuan+sqrt(B_tuoyuan^2+(A_tuoyuan-C_tuoyuan).^2));
% if(bb > aa)
%     temp = aa;
%     aa = bb;
%     bb = temp;
% end
% theta = asin(sign(-B_tuoyuan)*sqrt((A_tuoyuan*aa-C_tuoyuan*bb)*aa*bb/(aa*aa-bb*bb)));
% a = sqrt(aa);
% b = sqrt(bb);
% alpha = cos(theta).^2/a^2+sin(theta).^2/b^2;
% beta = sin(theta)*cos(theta)*(1/a^2-1/b^2);
% gama = cos(theta).^2/b^2+sin(theta).^2/a^2;
% y0 = (E_tuoyuan/2 - beta*D_tuoyuan/(2*alpha))/(beta^2/alpha - gama);
% x0 = (-D_tuoyuan/2 - beta*y0)/alpha;
% theta2 = 0:0.1:2*3.14159;
% x=x0+a*cos(theta2);
% y=y0+b*sin(theta2);
% plot(x,y,'g','linewidth',2);
% axis equal
% 
% legend('扰动');
