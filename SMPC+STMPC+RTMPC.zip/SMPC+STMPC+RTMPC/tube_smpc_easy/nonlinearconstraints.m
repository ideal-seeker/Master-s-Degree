function [c,ceq] = nonlinearconstraints(N, N_hat,T, t0, x0, u, sig, type)
    x = zeros(N+1, length(x0));
    x = computeOpenloopSolution( N, N_hat,T, t0, x0, u, type, sig);
    c = [];
    ceq = [];
        
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     %%%%% constraint tightening computation (& constraint generation)%%%%%%
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     
%     % compute covariance matrix propagation
%     sigma_e = cov_propagation(N, sig);
%     
%     g = [1;0];              % constraint: g*x < h -> x1 < x1_limit
%     K = [0.2858 -0.4910];   % stabilizing state feedback law
%             
%     for k=1:N               % k=1 refers to the initial state, so (technically) no state constraint necessary, but k=1 necessary for input constraint
%         gamma = sqrt(2*g'*sigma_e(:,:,k)*g)*erfinv(2*beta-1);                   % constraint tightening
%         [cnew, ceqnew] = constraints(t0+k*T,x(k,:),u(:,k), gamma, K, params);   % generate constraints
%         c = [c cnew];
%         ceq = [ceq ceqnew];
%     end
%     [cnew, ceqnew] = terminalconstraints(t0+(N+1)*T,x(N+1,:));
%     c = [c cnew];
%     ceq = [ceq ceqnew];
%     
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     %%%%%%%%%%%%%%%%%%%%% end of constraint tightening %%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end