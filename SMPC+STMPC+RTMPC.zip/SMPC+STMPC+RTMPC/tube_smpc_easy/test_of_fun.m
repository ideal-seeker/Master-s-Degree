funw = @f_alpha;
N_test=1e5;
a=zeros(N,1); %存放随机数的数列
alpha_X = linspace(0,alpha_bar,N_test);
ff = funw(alpha_X);
MM = max(ff);
n=0;
while n<N
    t=rand(1)*alpha_bar;%生成[0,24]均匀分布随机数

    f=funw(t)/MM;
    %计算对应密度函数值f(t)
    r=rand(1);  %生成[0,1]均匀分布随机数
    if r<=f     %如果随机数r小于f(t)，接纳该t并加入序列a中
        n=n+1;
        a(n)=t;
    end
end
%以上为生成随机数列a的过程，以下为统计检验随机数列是否符合分布
% num=100;         %分100个区间统计
% [x,c]=hist(a,num);    %统计不同区间出现的个数
% dc=alpha_X/num;        %区间大小
% x=x/N_test/dc;         %根据统计结果计算概率密度

% bar(c,x,1); hold on;  %根据统计结果画概率密度直方图
plot(alpha_X,a(n),'r'); %根据公式画概率密度曲线