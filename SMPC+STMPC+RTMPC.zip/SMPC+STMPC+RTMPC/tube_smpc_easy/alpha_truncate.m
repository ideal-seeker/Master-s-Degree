function [f_alpha,F_alpha] = alpha_truncate(x,t)
%ALPHA_TRUNCATE 此处显示有关此函数的摘要
%   此处显示详细说明
% A = evalin('base','A');
% n = size(A,1);
% ziyoudu=1;

f_alpha = pdf(t,x);
F_alpha = cdf(t,x);
end

