function [yueshu,cun,a, b, Aeq, beq] = linearconstraints(k,x0,N,N_hat)%k是第k行
%双模，MODE1用式(27),MODE2用式(32)
g=evalin('base','g');
h=evalin('base','h');
b_bars=evalin('base','b_bars');
V_inv=evalin('base','V_inv');
fai=evalin('base','fai');
% Nc=evalin('base','Nc');
lambda = evalin('base','lambda');
B_u=evalin('base','B_u');
fai_end_z = eye(size(fai,1));
fai_end_c = eye(size(fai,1));
alpha_bar = evalin('base','alpha_bar');
% count_ref = evalin('base','count_ref');
b_inf = alpha_bar/(1-lambda);
a=zeros(1,size(B_u,2)*N);%当u的维数变化的时候这里要变。
%1~N
Aeq = [];
beq = [];
if k<=N
    %试一下让第一个约束变成有效约束，或者让第一个约束严格一点，先试试有效约束吧
    if k==1
        a=[];
        b=[];
        Aeq = [g'*B_u,zeros(1,(N-1)*size(B_u,2))];
        beq = h-(b_bars(k)^0.5)*(g'*V_inv*g)^0.5-g'*fai*x0;
        cun = h-(b_bars(k)^0.5)*(g'*V_inv*g)^0.5;
        yueshu = beq;
    else
        for i = 1:1:k
            fai_end_z =  fai*fai_end_z;%mpciter从0开始
            if i == k%k是行数，i是列数
                fai_end_c = eye(size(fai,1));
            elseif i<k
                fai_end_c = eye(size(fai,1));
                for j = i:1:k-1
                    fai_end_c  = fai*fai_end_c ;
                end
            end
            a(:,size(B_u,2)*(i-1)+1:size(B_u,2)*i) = g'*fai_end_c*B_u;%当u的维数变化的时候这里要变。这个2？？？？？？明天看一看    2023.10.20
        end
        b = h-(b_bars(k)^0.5)*(g'*V_inv*g)^0.5-g'*fai_end_z*x0;
        %N~N+N_hat
        cun = h-(b_bars(k)^0.5)*(g'*V_inv*g)^0.5;
    end
elseif k>N && k<=N+N_hat
    A_edge_1 = eye(size(fai,1));
    for t =1:1:k-N
        A_edge_1 = fai*A_edge_1;
    end
    for i = 1:1:N
        fai_end_z =  fai*fai_end_z;%mpciter从0开始
        if i == N%k是行数，i是列数
            fai_end_c = eye(size(fai,1));
        elseif i<N
            fai_end_c = eye(size(fai,1));
            for j = i:1:N-1
                fai_end_c  = fai*fai_end_c ;
            end
        end
        % B_u = BK_tilde(:,:,mod(mpciter+i-2,count_ref)+1);
        a(:,size(B_u,2)*(i-1)+1:size(B_u,2)*i) = g'* A_edge_1 *fai_end_c*B_u;
    end
    b = h-(b_bars(k)^0.5)*(g'*V_inv*g)^0.5-g'*A_edge_1*fai_end_z*x0;
    % N+N_hat~N+N_hat+n_star
    cun = h-(b_bars(k)^0.5)*(g'*V_inv*g)^0.5;
elseif k>N+N_hat
    A_edge_2 = eye(size(fai,1));
    for t =1:1:k-N
        A_edge_2 = fai*A_edge_2;
    end
    for i = 1:1:N
        fai_end_z =  fai*fai_end_z;%mpciter从0开始
        if i == N%k是行数，i是列数
            fai_end_c = eye(size(fai,1));
        elseif i<N
            fai_end_c = eye(size(fai,1));
            for j = i:1:N-1
                fai_end_c  = fai*fai_end_c ;
            end
        end
        % B_u = BK_tilde(:,:,mod(mpciter+i-2,count_ref)+1);
        a(:,size(B_u,2)*(i-1)+1:size(B_u,2)*i) = g'* A_edge_2 *fai_end_c*B_u;
    end
    b = h-(b_inf^0.5)*(g'*V_inv*g)^0.5-g'*A_edge_2 *fai_end_z*x0;
    cun = h-(b_inf^0.5)*(g'*V_inv*g)^0.5;
end
    yueshu = b;
