# 单theta每个标量分别更新太慢，换成整个大矩阵参数一起更新的形式
# 利用动态模型进行更新
# 能运行，但是不往大了更新10/9 10:41
# 直接用backward更新Actor
import random
import numpy as np
import collections
from tqdm import tqdm
import scipy.stats as stats
import torch
import torch.nn.functional as F
from torch.distributions import Normal
import matplotlib.pyplot as plt
import rl_utils
from torchviz import make_dot
from torchrl.modules import TruncatedNormal
import time
def construct_matrix(F, I, gamma, N):
    # 创建一个 F-N x F 的零矩阵
    matrix = np.zeros((F, F))

    # 填充对角线元素
    np.fill_diagonal(matrix, I)

    # 填充上方的斜线元素
    for i in range(1, F):
        if i < N:  # 只填充到 N-1 次方
            np.fill_diagonal(matrix[:-i, i:], gamma ** i)

    used = matrix[:F-N+1, :]
    return torch.tensor(used).to(torch.float32)

class dynamic:
    def __init__(self, A, B, D, x_dim, u_dim, mu, sigma, lower, upper, cost_tensor, constraint_tensor_left,
                 constraint_tensor_right, N, delta):
        self.A = A
        self.B = B
        self.D = D
        self.x_dim = x_dim
        self.u_dim = u_dim
        self.mu = mu
        self.sigma = sigma
        self.lower = lower
        self.upper = upper
        self.state = 0
        self.cost_tensor = cost_tensor
        self.delta = delta
        self.constraint_l = constraint_tensor_left
        self.constraint_r = constraint_tensor_right
        self.N = N
    def reset(self):
        self.ve = np.random.uniform(0, 3.5)  # 初始化控制车速度
        self.vf = np.random.uniform(0.5, 3)  # 初始化被跟踪车速度
        self.error = np.random.uniform(1.5,2.5)  # 初始化两车间距
        self.state = torch.tensor([[self.ve], [self.vf], [self.error]])
        return self.state
    def step(self,action):#使用输入值更新状态
        dist = torch.nn.init.trunc_normal_(torch.empty(1, 1), mean=self.mu, std=self.sigma, a=self.lower, b=self.upper)
        self.state = torch.matmul(self.A, self.state)+torch.matmul(self.B, action)+torch.matmul(self.D, dist) #列向量
        reward = torch.matmul(self.cost_tensor, self.state) # 标量
        done = self.state[-1,0] <= 0              # 标量
        return self.state, reward, done

    def seed(self, seed_value):
        np.random.seed(seed_value)

class PolicyNet(torch.nn.Module): # 需要行向量
    def __init__(self, state_dim, hidden_dim, action_dim):
        super(PolicyNet,self).__init__()
        self.fc1 = torch.nn.Linear(state_dim,hidden_dim)
        self.fc2_mu = torch.nn.Linear(hidden_dim,action_dim)
        self.fc2_sigma = torch.nn.Linear(hidden_dim,action_dim)

    def forward(self,x):
        x = F.relu(self.fc1(x))
        mu = self.fc2_mu(x)
        sigma = F.softplus(self.fc2_sigma(x))+1e-5#输出具有非负平滑的性质
        return mu, sigma

class ValueNet(torch.nn.Module): # 需要行向量
    def __init__(self, state_dim, action_dim, hidden_dim):
        super(ValueNet,self).__init__()
        self.fc1 = torch.nn.Linear(state_dim+action_dim,hidden_dim)
        self.fc2 = torch.nn.Linear(hidden_dim,1)
    def forward(self,s,a):
        x = torch.cat((s,a),-1)
        x = F.relu(self.fc1(x))
        return self.fc2(x)
class CCAC:

    def __init__(self,state_dim,hidden_dim,action_dim,actor_lr,critic_lr,device,action_lower,action_upper,gamma,N,A,B,D,cost_tensor):
        self.actor = PolicyNet(state_dim,hidden_dim, action_dim).to(device)
        self.critic = ValueNet(state_dim,action_dim, hidden_dim).to(device)
        self.actor_optimizer = torch.optim.Adam(self.actor.parameters(),lr = actor_lr)
        self.critic_optimizer = torch.optim.Adam(self.critic.parameters(),lr = critic_lr)
        self.gamma = gamma
        self.device = device
        self.action_lower = action_lower
        self.action_upper = action_upper
        self.N = N
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.hidden_dim = hidden_dim
        self.A = A
        self.B = B
        self.D = D
        self.cost_tensor = cost_tensor
        self.actor_lr = actor_lr
        self.critic_lr = critic_lr
    def take_action(self,state):
        mu, sigma = self.actor(state)#好像自动就用forward了
        #print('ka?action_dist?')
        action_dist = TruncatedNormal(mu,sigma,1,self.action_lower,self.action_upper)
        action = action_dist.rsample()
        #print('没有')
        #dot = make_dot(action, params=dict(self.actor.named_parameters()))
        #dot.render("actor_param", format="png")  # 保存为 PNG 文件
        return mu, sigma, action

    def update(self, transition_dict):#利用采样值更新更新网络
        #start_time = time.time()
        rows = len(transition_dict['rewards'])#一次更新收集到的总数据数量（episode的长度）
        #辅助矩阵
        diagonal_matrix = construct_matrix(rows,1,self.gamma,self.N)
        states = torch.cat(transition_dict['states'], dim=1).transpose(0,1).to(self.device)
        actions = torch.cat(transition_dict['actions'], dim=1).transpose(0,1).to(self.device)
        rewards = torch.cat(transition_dict['rewards'], dim=0).unsqueeze(1).to(self.device)
        next_states = torch.cat(transition_dict['next_states'], dim=1).transpose(0,1).view(-1,self.state_dim).to(self.device)

        rewards_in_use = torch.matmul(diagonal_matrix, rewards).to(self.device) #这个挺有用的，在actor的更新里也能用，52*1
        V_plus = self.critic(next_states.detach()[-(rows-self.N+1):], actions.detach()[-(rows-self.N+1):])
        td_target = rewards_in_use + (self.gamma**self.N) * V_plus #多数据训练
        V_common = self.critic(states.detach()[:rows-self.N+1], actions.detach()[:rows-self.N+1])
        #end_time = time.time()
        #elapsed_time = end_time - start_time
        #print(f"列表数据处理用时：{elapsed_time:.4f} 秒")
        # 梯度部分
        # 更新Critic网络
        #start_time = time.time()
        critic_loss = torch.mean(F.mse_loss(V_common, td_target.detach().to(torch.float32)))# 强化学习的更新公式里不考虑值函数对actor网络的求导
        self.critic_optimizer.zero_grad()
        critic_loss.backward()#顺序来说应该是先更新Q再更新\pi吧，这里目标是拿到是对w的导数
        torch.nn.utils.clip_grad_norm_(self.critic.parameters(), max_norm=1)# 先把critic网络的参数更新好，这个和一般AC是一样的。
        self.critic_optimizer.step()#Critic网络更新完毕
        #end_time = time.time()
        #elapsed_time = end_time - start_time
        #print(f"critic网络更新用时：{elapsed_time:.4f} 秒")
        # 更新Actor网络
        start_time = time.time()
        actor_loss = torch.mean(-(rewards_in_use+self.gamma**self.N*self.critic(next_states[-(rows-self.N+1):], actions[-(rows-self.N+1):])))#10.8.21.07，写J的表达式
        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.actor.parameters(), max_norm=1)
        self.actor_optimizer.step()# Adam默认是梯度下降！！想要求max需要在actorloss加个负号！！！
        #end_time = time.time()
        #elapsed_time = end_time - start_time
        #print(f"actor网络更新用时：{elapsed_time:.4f} 秒")

def train_on_policy_agent(env, agent, num_episodes, times, little_update, longest, shortest):
    return_list = []
    for i in range(times):
        start_time = time.time()
        with tqdm(total=int(num_episodes/times), desc='Iteration %d' % i) as pbar:
            for i_episode in range(int(num_episodes/times)):
                length = shortest
                while length <= shortest:
                    episode_return = 0
                    transition_dict = {'states': [], 'actions': [], 'next_states': [], 'rewards': [], 'dones': [],
                                       'mu': [], 'sigma': []}
                    done = False
                    num = 0
                    state = env.reset()  # env中reset的状态形状是列向量
                    while (not done) and (num <= longest): #一个trajectory的数据记录
                        #start_time = time.time()
                        num += 1
                        mu, sigma, action = agent.take_action(state.transpose(0,1))#mu是用state_can_grad算出来的，因此mu后续的操作结果进行反向传播应该会累计梯度到state_can_grad上

                        next_state, reward, done = env.step(action) # 输出是列，需要转成行
                        transition_dict['states'].append(state)
                        transition_dict['actions'].append(action)
                        transition_dict['next_states'].append(next_state)
                        transition_dict['rewards'].append(reward)
                        transition_dict['dones'].append(done)
                        transition_dict['mu'].append(mu)
                        transition_dict['sigma'].append(sigma)
                        state = next_state
                        episode_return += reward
                    #end_time = time.time()
                    #all_time = end_time-start_time
                    #print(f"采样前面循环时间{all_time:.4f} 秒")
                    #start_time = time.time()
                    mu, sigma, action = agent.take_action(state.view(1,-1))
                    transition_dict['actions'].append(action)
                    transition_dict['mu'].append(mu)
                    transition_dict['sigma'].append(sigma)
                    length = len(transition_dict['rewards'])
                    #end_time = time.time()
                    #all_time = end_time-start_time
                    #print(f"最后一位采样时间{all_time:.4f} 秒")
                return_list.append(episode_return)
                agent.update(transition_dict)
                if ((i_episode+1) % little_update) == 0:
                    end_time = time.time()
                    yizu_time = end_time-start_time
                    pbar.set_postfix({'episode': '%d' % (num_episodes/times * i + i_episode + 1),
                                      'return': '%.3f' % torch.mean(torch.cat(return_list[-little_update:],dim=0)),
                                      '训练一组的时间(s)': '%.3f' %yizu_time})
                pbar.update(1)


    return return_list
# 后续还要对梯度的更新方程进行修改，改成CCAC的
# 具体实现：
actor_lr = 1e-3
critic_lr = 1e-4
num_episodes = 500
times = 25
little_update = 20
hidden_dim = 128
gamma = 0.98
device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")
T = 0.1
N = 1
dyn_A = torch.tensor([[1, 0, 0], [0, 1, 0], [-T, T, 1]], dtype=torch.float32)
dyn_B = torch.tensor([[T, 0, 0]], dtype=torch.float32).view(-1, 1)
dyn_D = torch.tensor([[0, 0, T]], dtype=torch.float32).view(-1, 1)
state_dim = dyn_A.shape[0]
action_dim = dyn_B.shape[1]
mu = 0
sigma = 1
lower = -5
upper = 5
action_lower = -4
action_upper = 3
cost_tensor = torch.tensor([0.2, 0, -0.05], dtype=torch.float32)
constraint_tensor_left = torch.tensor([0, 0, 1], dtype=torch.float32)
constraint_tensor_right = 2
delta = 0.98

shortest = N+10
longest = N+100
env = dynamic(dyn_A, dyn_B, dyn_D, state_dim, action_dim,mu,sigma,lower,upper,cost_tensor,constraint_tensor_left,constraint_tensor_right,N,delta )
env.seed(0)
torch.manual_seed(0)
agent = CCAC(state_dim, hidden_dim, action_dim, actor_lr, critic_lr, device, action_lower, action_upper, gamma, N,dyn_A,dyn_B,dyn_D,cost_tensor)

return_list = train_on_policy_agent(env, agent, num_episodes, times, little_update, longest ,shortest)
episodes_list = list(range(len(return_list)))
return_list_plot = [t.item() for t in return_list]
plt.plot(episodes_list, return_list_plot)
plt.xlabel('Episodes')
plt.ylabel('Returns')
plt.title('Actor-Critic on {}'.format('my_cars'))
plt.show()
mv_return = rl_utils.moving_average(return_list_plot, 9)
plt.plot(episodes_list, mv_return)
plt.xlabel('Episodes')
plt.ylabel('Returns')
plt.title('Actor-Critic on {}'.format(env))
plt.show()