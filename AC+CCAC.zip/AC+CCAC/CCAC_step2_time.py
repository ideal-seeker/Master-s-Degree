
#看一下哪里比有模型慢
#无约束无模型（就是普通AC）
# 能用
import random
import time

import numpy as np
import collections
from tqdm import tqdm
import scipy.stats as stats
import torch
import torch.nn.functional as F
import matplotlib.pyplot as plt
import rl_utils

def construct_matrix(F, I, gamma, N):
    # 创建一个 F-N x F 的零矩阵
    matrix = np.zeros((F, F))

    # 填充对角线元素
    np.fill_diagonal(matrix, I)

    # 填充上方的斜线元素
    for i in range(1, F):
        if i < N:  # 只填充到 N-1 次方
            np.fill_diagonal(matrix[:-i, i:], gamma ** i)

    used = matrix[:F-N+1, :]
    return used

class dynamic:
    def __init__(self, A, B, D, x_dim, u_dim, mu, sigma, lower, upper, cost_tensor, constraint_tensor_left,
                 constraint_tensor_right, N, delta):
        self.A = A
        self.B = B
        self.D = D
        self.x_dim = x_dim
        self.u_dim = u_dim
        self.mu = mu
        self.sigma = sigma
        self.lower = lower
        self.upper = upper
        self.state = 0
        self.cost_tensor = cost_tensor
        self.delta = delta
        self.constraint_l = constraint_tensor_left
        self.constraint_r = constraint_tensor_right
        self.N = N

    def reset(self):
        self.ve = np.random.uniform(0, 3.5)  # 初始化控制车速度
        self.vf = np.random.uniform(0.5, 3)  # 初始化被跟踪车速度
        self.error = np.random.uniform(1.5,2.5)  # 初始化两车间距
        self.state = np.array([[self.ve], [self.vf],[self.error]])
        return self.state
    def step(self,action):#使用输入值更新状态
        acceleration = action.item()
        dist = stats.truncnorm.rvs((self.lower - self.mu) / self.sigma,
                                   (self.upper - self.mu) / self.sigma, loc=self.mu,
                                   scale=self.sigma, size=1).reshape(1,-1)
        self.state = np.dot(self.A,self.state)+np.dot(self.B,acceleration)+np.dot(self.D,dist) #列向量
        reward = np.dot(self.cost_tensor, self.state) # 标量
        done = self.state[-1,0] <= 0              # 标量
        return self.state, reward, done

    def seed(self, seed_value):
        np.random.seed(seed_value)

class PolicyNet(torch.nn.Module): # 需要行向量
    def __init__(self, state_dim, hidden_dim, action_dim):
        super(PolicyNet,self).__init__()
        self.fc1 = torch.nn.Linear(state_dim,hidden_dim)
        self.fc2_mu = torch.nn.Linear(hidden_dim,action_dim)
        self.fc2_sigma = torch.nn.Linear(hidden_dim,action_dim)

    def forward(self,x):
        x = F.relu(self.fc1(x))
        mu = self.fc2_mu(x)
        sigma = F.softplus(self.fc2_sigma(x))+1e-5#输出具有非负平滑的性质
        return mu,sigma

class ValueNet(torch.nn.Module): # 需要行向量
    def __init__(self, state_dim, action_dim, hidden_dim):
        super(ValueNet,self).__init__()
        self.fc1 = torch.nn.Linear(state_dim+action_dim,hidden_dim)
        self.fc2 = torch.nn.Linear(hidden_dim,1)
    def forward(self,s,a):
        x = torch.cat((s,a),-1)
        x = F.relu(self.fc1(x))
        return self.fc2(x)
class CCAC:

    def __init__(self,state_dim,hidden_dim,action_dim,actor_lr,critic_lr,device,action_lower,action_upper,gamma,N):
        self.actor = PolicyNet(state_dim,hidden_dim, action_dim).to(device)
        self.critic = ValueNet(state_dim,action_dim, hidden_dim).to(device)
        self.actor_optimizer = torch.optim.Adam(self.actor.parameters(),lr = actor_lr)
        self.critic_optimizer = torch.optim.Adam(self.critic.parameters(),lr = critic_lr)
        self.gamma = gamma
        self.device = device
        self.action_lower = action_lower
        self.action_upper = action_upper
        self.N = N
        self.state_dim = state_dim
        self.critic_time = 0
        self.actor_time = 0
        self.cy_time = 0
        self.num=0
    def take_action(self,state):
        state = torch.tensor([state],dtype=torch.float).to(self.device)
        mu,sigma = self.actor(state)#好像自动就用forward了
        dist_a = stats.truncnorm((self.action_lower-mu.detach().item())/sigma.detach().item(), (self.action_upper-mu.detach().item())/sigma.detach().item(),mu.detach().item(),sigma.detach().item())
        action = dist_a.rvs(size=1)
        return mu, sigma, action

    def update(self,transition_dict,cy_time,num):#利用采样值更新更新网络
        self.cy_time+=cy_time
        self.cy_time+=cy_time
        self.num+=num
        rows = len(transition_dict['rewards'])
        diagonal_matrix = construct_matrix(rows,1,self.gamma,self.N)
        diagonal_qu = torch.eye(rows)[self.N-1:]
        diagonal_be = torch.eye(rows)[:rows-self.N+1]
        diag_ac_be = torch.eye(rows+1)[:rows-self.N+1]
        diag_ac_qu = torch.eye(rows+1)[self.N:]
        states = torch.tensor(transition_dict['states'],
                              dtype=torch.float).transpose(1,2).view(-1,self.state_dim).to(self.device)

        actions = torch.tensor(transition_dict['actions']).view(-1, 1).to(
            self.device)
        rewards = torch.tensor(transition_dict['rewards'],
                               dtype=torch.float).view(-1, 1).to(self.device)
        next_states = torch.tensor(transition_dict['next_states'],
                                   dtype=torch.float).transpose(1,2).view(-1,self.state_dim).to(self.device)
        dones = torch.tensor(transition_dict['dones'],
                             dtype=torch.float).view(-1, 1).to(self.device)

        mu = torch.stack(transition_dict['mu']).view(-1, 1).to(self.device)
        sigma = torch.stack(transition_dict['sigma']).view(-1, 1).to(self.device)
        states_in_use = torch.mm(diagonal_be, states)
        rewards_in_use = torch.tensor(np.dot(diagonal_matrix, rewards)).to(self.device)
        next_states_in_use = torch.mm(diagonal_qu, next_states).to(self.device)
        dones_in_use = torch.mm(diagonal_qu, dones).to(self.device)
        actions_in_use_be = torch.mm(diag_ac_be, actions.to(torch.float32)).to(self.device)
        actions_in_use_qu = torch.mm(diag_ac_qu, actions.to(torch.float32)).to(self.device)
        V_plus = self.critic(next_states_in_use, actions_in_use_qu)
        td_target = rewards_in_use + (self.gamma**self.N) * V_plus #多数据训练
        V_common = self.critic(states_in_use, actions_in_use_be)
        td_delta = td_target-(V_common.detach())#是因为这里加了个负号导致的？
        #梯度部分

        normal_dist = torch.distributions.Normal(mu,sigma)

        log_probs = torch.mm(diagonal_be, normal_dist.log_prob(actions[:rows]).float())
        # 更新Critic网络
        start_time = time.time()
        critic_loss = torch.mean(F.mse_loss(self.critic(states_in_use,actions_in_use_be), td_target.detach().to(torch.float32)))# 强化学习的更新公式里不考虑值函数对actor网络的求导
        self.critic_optimizer.zero_grad()
        critic_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.critic.parameters(), max_norm=1)
        self.critic_optimizer.step()
        end_time = time.time()
        elapsed_time = end_time - start_time
        self.critic_time += elapsed_time
        #print(f"critic网络更新用时：{elapsed_time:.4f} 秒")
        # 更新Actor网络
        start_time = time.time()
        actor_loss = torch.mean(-log_probs * td_delta.detach())#这是逐元素相乘,这里应该对应公式里的\sum_{t=0}^{T}
        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.actor.parameters(), max_norm=1)
        self.actor_optimizer.step()  # Adam默认是梯度下降！！想要求max需要在actorloss加个负号！！！
        end_time = time.time()
        elapsed_time = end_time - start_time
        self.actor_time += elapsed_time
        #print(f"actor网络更新用时：{elapsed_time:.4f} 秒")

def train_on_policy_agent(env,agent,num_episodes,times, little_update, longest,shortest):
    return_list = []
    for i in range(times):
        with tqdm(total=int(num_episodes/times), desc='Iteration %d' % i) as pbar:
            for i_episode in range(int(num_episodes/times)):
                start_time = time.time()
                length = shortest
                while length <= shortest:
                    episode_return = 0
                    transition_dict = {'states': [], 'actions': [], 'next_states': [], 'rewards': [], 'dones': [],
                                       'mu': [], 'sigma': []}
                    done = False
                    num = 0
                    state = env.reset()  # env中reset的状态形状是列向量
                    while (not done) and (num <= longest): #一个trajectory的数据记录
                        num += 1
                        mu, sigma, action = agent.take_action(state.reshape(1,-1))

                        next_state, reward, done = env.step(action) # 输出是列，需要转成行
                        transition_dict['states'].append(state)
                        transition_dict['actions'].append(action)
                        transition_dict['next_states'].append(next_state)
                        transition_dict['rewards'].append(reward)
                        transition_dict['dones'].append(done)
                        transition_dict['mu'].append(mu)
                        transition_dict['sigma'].append(sigma)
                        state = next_state
                        episode_return += reward
                    _,_,action = agent.take_action(state.reshape(1,-1))
                    transition_dict['actions'].append(action)
                    length = len(transition_dict['rewards'])

                return_list.append(episode_return)
                end_time = time.time()
                cy_time = end_time-start_time
                agent.update(transition_dict,cy_time,num)
                if ((i_episode+1) % little_update) == 0:

                    pbar.set_postfix({'episode': '%d' % (num_episodes/times * i + i_episode + 1),
                                      'return': '%.3f' % np.mean(return_list[-little_update:])
                                      })

                pbar.update(1)
    return return_list
# 后续还要对梯度的更新方程进行修改，改成CCAC的
# 具体实现：
actor_lr = 1e-3
critic_lr = 1e-4
num_episodes = 500
times = 25
little_update = 20
hidden_dim = 128
gamma = 0.98
device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")
T = 0.1

dyn_A = np.array([[1, 0, 0], [0, 1, 0], [-T, T, 1]])
dyn_B = np.array([T, 0, 0]).reshape(-1, 1)
dyn_D = np.array([0, 0, T]).reshape(-1, 1)
state_dim = dyn_A.shape[0]
action_dim = dyn_B.shape[1]
mu = 0
sigma = 1
lower = -5
upper = 5
action_lower = -4
action_upper = 3
cost_tensor = np.array([0.2, 0, -0.05])
constraint_tensor_left = np.array([0, 0, 1])
constraint_tensor_right = 2
N = 1
delta = 0.98

shortest = N+10
longest = N+100
env = dynamic(dyn_A, dyn_B, dyn_D, state_dim, action_dim,mu,sigma,lower,upper,cost_tensor,constraint_tensor_left,constraint_tensor_right,N,delta )
env.seed(0)
torch.manual_seed(0)
agent = CCAC(state_dim, hidden_dim, action_dim, actor_lr, critic_lr, device, action_lower, action_upper, gamma, N)

return_list = train_on_policy_agent(env, agent, num_episodes, times, little_update, longest ,shortest)
print(f"critic更新总用时:{agent.critic_time}秒")
print(f"actor更新总用时:{agent.actor_time}秒")
print(f"采样总用时:{agent.cy_time}秒")
print(f"采样总次数:{agent.num}次")
episodes_list = list(range(len(return_list)))
plt.plot(episodes_list, return_list)
plt.xlabel('Episodes')
plt.ylabel('Returns')
plt.title('Actor-Critic on {}'.format('my_cars'))
plt.show()
mv_return = rl_utils.moving_average(return_list, 9)
plt.plot(episodes_list, mv_return)
plt.xlabel('Episodes')
plt.ylabel('Returns')
plt.title('Actor-Critic on {}'.format(env))
plt.show()