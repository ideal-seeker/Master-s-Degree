class digui:
    def __init__(self):
        self.res = 0
    def jiecheng(self,n):
        if n==1:
            return 1
        else:
            return n*self.jiecheng(n-1)
a = digui()
print(a.jiecheng(4))
