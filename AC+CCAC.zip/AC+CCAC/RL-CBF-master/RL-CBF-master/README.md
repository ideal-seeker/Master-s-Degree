# RL-CBF
This code implements the RL-CBF algorithm on top of two baseline model-free algorithms: Trust Region Policy Optimization (TRPO) and Deep Deterministic Policy Gradients (DDPG). The RL-CBF algorithm provides safety guarantees during the learning process, and details of the algorithm can be found in the paper "End-to-End Safe Reinforcement Learning for Safety-Critical Continuous Control Tasks". We show learning on two simulated tasks: (1) Inverted Pendulum Control, (2) Car-Following in a chain of 5 cars.

Within each folder for each problem domain, there are 4 subfolders implementing the RL algorithms:
TRPO-CBF - Run the RL-CBF algorithm on top of TRPO. For the car-following example, run sim.py to begin learning. For the pendulum example, run main.py to begin learning. 
DDPG-CBF - Run the RL-CBF algorithm on top of DDPG. For both examples, run ddpg.py to begin learning.
TRPO - Run the baseline TRPO algorithm for comparison. For the car-following example, run sim.py to begin learning. For the pendulum example, run main.py to begin learning. 
DDPG - Run the baseline DDPG algorithm. For both examples, run ddpg.py to begin learning.

The files plotResults.m and plotCollisions.m can be run in MATLAB to generate plots of the reward and safety violations, respectively, as seen in the paper. However due to space constraints, the data files are not included, here, but all code with the data files can be found at: https://www.dropbox.com/sh/23t9ez2ho3wbp7g/AABGjN1GSvYkCEE8xA7cB707a?dl=0

Hyperparameters can be tuned in the sim.py or main.py files for car-following and pendulum, respectively. Once learning is finished (for the specified number of iterations), data is output in a .mat file, which includes rewards and trajectories for each episode. For any questions/issues regarding the code, contact rcheng@caltech.edu. 

translate:

这段代码在两个基线无模型算法（信任区域策略优化 TRPO 和深度确定性策略梯度 DDPG）上实现了 RL-CBF 算法。RL-CBF 算法在学习过程中提供了安全保障，算法的详细信息可以在论文《面向安全关键连续控制任务的端到端安全强化学习》中找到。我们展示了两个模拟任务的学习：（1）倒立摆控制，（2）5 辆车的跟车任务。

在每个问题领域的文件夹中，有4个子文件夹实现了 RL 算法：

TRPO-CBF：在 TRPO 上运行 RL-CBF 算法。对于跟车示例，运行 sim.py 开始学习。对于摆的示例，运行 main.py 开始学习。

DDPG-CBF：在 DDPG 上运行 RL-CBF 算法。对于两个示例，运行 ddpg.py 开始学习。

TRPO：运行基线 TRPO 算法以进行比较。对于跟车示例，运行 sim.py 开始学习。对于摆的示例，运行 main.py 开始学习。

DDPG：运行基线 DDPG 算法。对于两个示例，运行 ddpg.py 开始学习。

文件 plotResults.m 和 plotCollisions.m 可以在 MATLAB 中运行，以生成奖励和安全违规的图表，如论文中所示。但由于空间限制，数据文件未包含在内，所有代码和数据文件可以在以下链接找到：Dropbox链接。

超参数可以在 sim.py 或 main.py 文件中进行调整，分别用于跟车和摆的任务。一旦学习完成（达到指定的迭代次数），数据将输出到一个 .mat 文件中，其中包括每个回合的奖励和轨迹。如有关于代码的任何问题或疑问，请联系 rcheng@caltech.edu。

如果您需要进一步的帮助或有其他内容需要翻译，请告诉我