#单theta每个标量分别更新太慢，换成整个大矩阵参数一起更新的形式
import random
import numpy as np
import collections
from tqdm import tqdm
import scipy.stats as stats
import torch
import torch.nn.functional as F
import matplotlib.pyplot as plt
import rl_utils
from torchviz import make_dot

def construct_matrix(F, I, gamma, N):
    # 创建一个 F-N x F 的零矩阵
    matrix = np.zeros((F, F))

    # 填充对角线元素
    np.fill_diagonal(matrix, I)

    # 填充上方的斜线元素
    for i in range(1, F):
        if i < N:  # 只填充到 N-1 次方
            np.fill_diagonal(matrix[:-i, i:], gamma ** i)

    used = matrix[:F-N+1, :]
    return used

class dynamic:
    def __init__(self, A, B, D, x_dim, u_dim, mu, sigma, lower, upper, cost_tensor, constraint_tensor_left,
                 constraint_tensor_right, N, delta):
        self.A = A
        self.B = B
        self.D = D
        self.x_dim = x_dim
        self.u_dim = u_dim
        self.mu = mu
        self.sigma = sigma
        self.lower = lower
        self.upper = upper
        self.state = 0
        self.cost_tensor = cost_tensor
        self.delta = delta
        self.constraint_l = constraint_tensor_left
        self.constraint_r = constraint_tensor_right
        self.N = N
    def reset(self):
        self.ve = np.random.uniform(0, 3.5)  # 初始化控制车速度
        self.vf = np.random.uniform(0.5, 3)  # 初始化被跟踪车速度
        self.error = np.random.uniform(1.5,2.5)  # 初始化两车间距
        self.state = np.array([[self.ve], [self.vf],[self.error]])
        return self.state
    def step(self,action):#使用输入值更新状态
        acceleration = action.item()
        dist = stats.truncnorm.rvs((self.lower - self.mu) / self.sigma,
                                   (self.upper - self.mu) / self.sigma, loc=self.mu,
                                   scale=self.sigma, size=1).reshape(1,-1)
        self.state = np.dot(self.A,self.state)+np.dot(self.B,acceleration)+np.dot(self.D,dist) #列向量
        reward = np.dot(self.cost_tensor, self.state) # 标量
        done = self.state[-1,0] <= 0              # 标量
        return self.state, reward, done

    def seed(self, seed_value):
        np.random.seed(seed_value)

class PolicyNet(torch.nn.Module): # 需要行向量
    def __init__(self, state_dim, hidden_dim, action_dim):
        super(PolicyNet,self).__init__()
        self.fc1 = torch.nn.Linear(state_dim,hidden_dim)
        self.fc2_mu = torch.nn.Linear(hidden_dim,action_dim)
        self.fc2_sigma = torch.nn.Linear(hidden_dim,action_dim)

    def forward(self,x):
        x = F.relu(self.fc1(x))
        mu = self.fc2_mu(x)
        sigma = F.softplus(self.fc2_sigma(x))+1e-5#输出具有非负平滑的性质
        return mu,sigma

class ValueNet(torch.nn.Module): # 需要行向量
    def __init__(self, state_dim, action_dim, hidden_dim):
        super(ValueNet,self).__init__()
        self.fc1 = torch.nn.Linear(state_dim+action_dim,hidden_dim)
        self.fc2 = torch.nn.Linear(hidden_dim,1)
    def forward(self,s,a):
        x = torch.cat((s,a),-1)
        x = F.relu(self.fc1(x))
        return self.fc2(x)
class CCAC:

    def __init__(self,state_dim,hidden_dim,action_dim,actor_lr,critic_lr,device,action_lower,action_upper,gamma,N,A,B,D,cost_tensor):
        self.actor = PolicyNet(state_dim,hidden_dim, action_dim).to(device)
        self.critic = ValueNet(state_dim,action_dim, hidden_dim).to(device)
        self.actor_optimizer = torch.optim.Adam(self.actor.parameters(),lr = actor_lr)
        self.critic_optimizer = torch.optim.Adam(self.critic.parameters(),lr = critic_lr)
        self.gamma = gamma
        self.device = device
        self.action_lower = action_lower
        self.action_upper = action_upper
        self.N = N
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.hidden_dim = hidden_dim
        self.A = A
        self.B = B
        self.D = D
        self.cost_tensor = cost_tensor
        self.actor_lr = actor_lr
        self.critic_lr = critic_lr
    def take_action(self,state):
        mu,sigma = self.actor(state)#好像自动就用forward了
        dist_a = stats.truncnorm((self.action_lower-mu.detach().item())/sigma.detach().item(), (self.action_upper-mu.detach().item())/sigma.detach().item(),mu.detach().item(),sigma.detach().item())
        action = dist_a.rvs()
        return mu, sigma, action

    def update(self, transition_dict):#利用采样值更新更新网络
        rows = len(transition_dict['rewards'])#一次更新收集到的总数据数量（episode的长度）
        #辅助矩阵
        diagonal_matrix = construct_matrix(rows,1,self.gamma,self.N)
        diagonal_af = torch.eye(rows)[self.N-1:]
        diagonal_be = torch.eye(rows)[:rows-self.N+1]


        states = torch.tensor(transition_dict['states'],dtype=torch.float).transpose(1,2).view(-1,self.state_dim).to(self.device)
        actions = torch.tensor(transition_dict['actions']).view(-1, 1).to(self.device)
        rewards = torch.tensor(transition_dict['rewards'],dtype=torch.float).view(-1, 1).to(self.device)
        next_states = torch.tensor(transition_dict['next_states'],dtype=torch.float).transpose(1,2).view(-1,self.state_dim).to(self.device)

        states_in_use = torch.mm(diagonal_be, states)
        actions_in_use_be = actions[:rows-self.N+1].to(torch.float32).to(self.device)
        actions_in_use_af = actions[self.N:].to(torch.float32).to(self.device)
        rewards_in_use = torch.tensor(np.dot(diagonal_matrix, rewards)).to(self.device)
        next_states_in_use = torch.mm(diagonal_af, next_states).to(self.device)

        V_plus = self.critic(next_states_in_use, actions_in_use_af)
        td_target = rewards_in_use + (self.gamma**self.N) * V_plus #多数据训练
        V_common = self.critic(states_in_use, actions_in_use_be)

        #梯度部分
        critic_loss = torch.mean(F.mse_loss(V_common, td_target.detach().to(torch.float32)))# 强化学习的更新公式里不考虑值函数对actor网络的求导
        #更新Critic网络
        self.critic_optimizer.zero_grad()
        critic_loss.backward()#顺序来说应该是先更新Q再更新\pi吧，这里目标是拿到是对w的导数
        torch.nn.utils.clip_grad_norm_(self.critic.parameters(), max_norm=1)# 先把critic网络的参数更新好，这个和一般AC是一样的。
        self.critic_optimizer.step()#Critic网络更新完毕

        #重点部分↓
        #更新Actor网络
        #self.actor_optimizer.zero_grad()不用优化器更新，不用o化
        self.grad_continue(transition_dict, rows)#目前是没考虑约束的动态模型梯度构造,类中的函数self不用手动传

    def grad_continue(self, transition_dict, rows):
        #JR循环（一个N）
        #准备梯度公式里所有需要的单元：
        #要做到一次对每个Actor网络里的参数（矩阵形式），通过一次计算就算出来，不用对t循环，不用对N循环,也不用对参数中的每个元素循环。2024/10/2
        rows_in_use = rows-self.N+1
        mu = torch.stack(transition_dict['mu']).view(-1, 1).to(self.device)
        sigma = torch.stack(transition_dict['sigma']).view(-1, 1).to(self.device)
        #计算求最终梯度需要的元素
        # 只有f,r,phi，psi需要四维
        # r对s,a的偏导
        nabla_r_s_t = torch.tensor(self.cost_tensor, dtype=torch.float32).repeat(rows_in_use,self.N,1,1)
        nabla_r_a_t = torch.zeros(rows_in_use,self.N,1,1)
        # f对s,a的偏导
        nabla_f_s_t = torch.tensor(self.A).float().repeat(rows_in_use,self.N,1,1)
        nabla_f_a_t = torch.tensor(self.B).float().repeat(rows_in_use,self.N,1,1)
        # Q对s,a的偏导
        states_Q = torch.tensor(transition_dict['states'], dtype=torch.float).view(-1,self.state_dim)[self.N-1:].to(self.device)
        actions_Q = torch.tensor(transition_dict['actions'], dtype=torch.float).view(-1, 1)[self.N:].to(self.device)
        states_Q.requires_grad_()
        actions_Q.requires_grad_()
        q_grad = self.critic(states_Q, actions_Q)
        if states_Q.grad is not None:
            states_Q.grad.zero()
        if states_Q.grad is not None:
            actions_Q.grad.zero()
        q_grad.backward(torch.ones_like(q_grad))
        nabla_q_s_N = states_Q.grad.unsqueeze(1)
        nabla_q_a_N = actions_Q.grad.unsqueeze(1)
        # 计算actor:\pi对s_t的偏导,什么形状？
        states_list_grad = transition_dict['states_can_grad'][:-1]
        actions = torch.tensor(transition_dict['actions']).view(-1, 1).to(self.device)
        normal_dist = torch.distributions.Normal(mu, sigma)  # 这个东西应该对应\pi_{a_t|s_t}
        probs = torch.exp(normal_dist.log_prob(actions)).float()
        for tensor in states_list_grad:
            if tensor.grad is not None:
                tensor.grad.zero_()
        probs.backward(torch.ones_like(probs))# 这里可以得到nabla_pi_Theta了
        torch.nn.utils.clip_grad_norm_(self.actor.parameters(), max_norm=1)
        torch.nn.utils.clip_grad_norm_(self.actor.parameters(), max_norm=1)
        gradients_list = [t.grad.transpose(0, 1) for t in states_list_grad]
        nabla_pi_s_t = torch.cat(gradients_list, dim = 0).unsqueeze(1)  # 列向量组成的长列表。
        # 用一个嵌套函数实nabla_J的计算


        # 手动更新actor参数
        torch.nn.utils.clip_grad_norm_(self.actor.parameters(), max_norm=1)
        with (torch.no_grad()):  # 禁止梯度计算
            for param in self.actor.parameters():#依次更新每个参数
                if param.grad is not None:
                    param_vector = param.view(1, -1)#一个矩阵形式的参数整体更新，把它先排成列向量形式
                    param_grad = param.grad.view(1, -1)
                    nabla_J_list = torch.empty(0, self.hidden_dim*self.state_dim)
                    for num in range(0, rows_in_use):# 取值0~51，代表所有的数据组
                        count = self.N
                        nabla_J = grad_J(num, count, nabla_r_s_t, nabla_r_a_t, nabla_f_s_t, nabla_f_a_t, nabla_q_s_N, nabla_q_a_N, nabla_pi_s_t, param_grad)
                        nabla_J_list = torch.cat(nabla_J_list, nabla_J, dim=0)
                    nabla_J_mean = nabla_J_list.mean(dim=0)
                    param_vector = param_vector+self.actor_lr*nabla_J_mean.view(-1, 1)
                    param = param_vector.view(*param.shape)




def grad_J(num,count,r_s,r_a,f_s,f_a,Q_s,Q_a,pi_s,pi_theta):
    if count==0:
        nabla_J = 0
        phi = torch.zeros(self.state_dim, self.hidden_dim*self.state_dim)
        psi = pi_theta
        nabla_J = nabla_J+self.gamma**count*(torch.matmul(r_s(定位),phi)+torch.matmul(r_a,psi))
        return phi, psi, nabla_J
    elif count < self.N:
        count -=1
        phi, psi, nabla_J = grad_J(num,count,r_s,r_a,f_s,f_a,Q_s,Q_a,pi_s,pi_theta)
        count += 1
        phi = torch.matmul(f_s,phi)+torch.matmul(f_a, psi)
        psi =torch.matmul(pi_s,phi)+pi_theta()
        nabla_J = nabla_J + self.gamma ** count * (torch.matmul(r_s(定位), phi) + torch.matmul(r_a, psi))
        return phi, psi, nabla_J
    elif count == self.N:
        count -= 1
        phi, psi, nabla_J = grad_J(num, count, r_s, r_a, f_s, f_a, Q_s, Q_a, pi_s, pi_theta)
        count += 1
        phi = torch.matmul(f_s(用self.N定位), phi) + torch.matmul(f_a, psi)
        psi = torch.matmul(pi_s, phi) + pi_theta()
        nabla_J = nabla_J + self.gamma ** count * (torch.matmul(Q_s(定位), phi) + torch.matmul(Q_a, psi))
        return nabla_J
    #尾部加上Q的


def train_on_policy_agent(env, agent, num_episodes, times, little_update, longest, shortest):
    return_list = []
    for i in range(times):
        with tqdm(total=int(num_episodes/times), desc='Iteration %d' % i) as pbar:
            for i_episode in range(int(num_episodes/times)):
                length = shortest
                while length <= shortest:
                    episode_return = 0
                    transition_dict = {'states': [], 'actions': [], 'next_states': [], 'rewards': [], 'dones': [],
                                       'mu': [], 'sigma': [], 'states_can_grad':[]}
                    done = False
                    num = 0
                    state = env.reset()  # env中reset的状态形状是列向量

                    while (not done) and (num <= longest): #一个trajectory的数据记录
                        num += 1
                        state_can_grad = torch.from_numpy(state).detach().float().requires_grad_()#对张量重复赋值后，两次初始值下的梯度保持独立，第一次赋值的张量计算过程已经固定且那个张量已经记录到了list中，不会被后续的变化所改变-来自GPT

                        mu, sigma, action = agent.take_action(state_can_grad.transpose(0,1))#mu是用state_can_grad算出来的，因此mu后续的操作结果进行反向传播应该会累计梯度到state_can_grad上
                        next_state, reward, done = env.step(action) # 输出是列，需要转成行
                        transition_dict['states'].append(state)
                        transition_dict['actions'].append(action)
                        transition_dict['next_states'].append(next_state)
                        transition_dict['rewards'].append(reward)
                        transition_dict['dones'].append(done)
                        transition_dict['mu'].append(mu)
                        transition_dict['sigma'].append(sigma)
                        transition_dict['states_can_grad'].append(state_can_grad)

                        state = next_state
                        episode_return += reward
                    state_can_grad = torch.from_numpy(state).detach().requires_grad_().float()
                    mu, sigma, action = agent.take_action(state_can_grad.view(1,-1))
                    transition_dict['states_can_grad'].append(state_can_grad)
                    transition_dict['actions'].append(action)
                    transition_dict['mu'].append(mu)
                    transition_dict['sigma'].append(sigma)
                    length = len(transition_dict['rewards'])

                return_list.append(episode_return)

                agent.update(transition_dict)
                if ((i_episode+1) % little_update) == 0:
                    pbar.set_postfix({'episode': '%d' % (num_episodes/times * i + i_episode + 1),
                                      'return': '%.3f' % np.mean(return_list[-little_update:])})
                pbar.update(1)
    return return_list
# 后续还要对梯度的更新方程进行修改，改成CCAC的
# 具体实现：
actor_lr = 1e-3
critic_lr = 1e-4
num_episodes = 500
times = 50
little_update = 10
hidden_dim = 128
gamma = 0.98
device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")
T = 0.1
N = 80
dyn_A = np.array([[1, 0, 0], [0, 1, 0], [-T, T, 1]])
dyn_B = np.array([T, 0, 0]).reshape(-1, 1)
dyn_D = np.array([0, 0, T]).reshape(-1, 1)
state_dim = dyn_A.shape[0]
action_dim = dyn_B.shape[1]
mu = 0
sigma = 1
lower = -5
upper = 5
action_lower = -4
action_upper = 3
cost_tensor = np.array([0.2, 0, -0.05])
constraint_tensor_left = np.array([0, 0, 1])
constraint_tensor_right = 2
N = 80
delta = 0.98

shortest = N+10
longest = N+50
env = dynamic(dyn_A, dyn_B, dyn_D, state_dim, action_dim,mu,sigma,lower,upper,cost_tensor,constraint_tensor_left,constraint_tensor_right,N,delta )
env.seed(0)
torch.manual_seed(0)
agent = CCAC(state_dim, hidden_dim, action_dim, actor_lr, critic_lr, device, action_lower, action_upper, gamma, N,dyn_A,dyn_B,dyn_D,cost_tensor)

return_list = train_on_policy_agent(env, agent, num_episodes, times, little_update, longest ,shortest)
episodes_list = list(range(len(return_list)))
plt.plot(episodes_list, return_list)
plt.xlabel('Episodes')
plt.ylabel('Returns')
plt.title('Actor-Critic on {}'.format('my_cars'))
plt.show()
mv_return = rl_utils.moving_average(return_list, 9)
plt.plot(episodes_list, mv_return)
plt.xlabel('Episodes')
plt.ylabel('Returns')
plt.title('Actor-Critic on {}'.format(env))
plt.show()