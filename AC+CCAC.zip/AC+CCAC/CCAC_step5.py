#有软约束有模型
#另一篇论文的逼近ps梯度方法，感觉也不是很好用
import random
import numpy as np
import collections
from tqdm import tqdm
import scipy.stats as stats
import torch
import torch.nn.functional as F
from torch.distributions import Normal
import matplotlib.pyplot as plt
import rl_utils
from torchviz import make_dot
from torchrl.modules import TruncatedNormal
import time
def construct_matrix(F, I, gamma, N):
    # 创建一个 F-N x F 的零矩阵
    matrix = np.zeros((F, F))

    # 填充对角线元素
    np.fill_diagonal(matrix, I)

    # 填充上方的斜线元素
    for i in range(1, F):
        if i < N:  # 只填充到 N-1 次方
            np.fill_diagonal(matrix[:-i, i:], gamma ** i)

    used = matrix[:F-N+1, :]
    return torch.tensor(used).to(torch.float32)

class dynamic:
    def __init__(self, A, B, D, x_dim, u_dim, mu, sigma, lower, upper, cost_tensor, constraint_tensor_left,
                 constraint_tensor_right, N):
        self.A = A
        self.B = B
        self.D = D
        self.x_dim = x_dim
        self.u_dim = u_dim
        self.mu = mu
        self.sigma = sigma
        self.lower = lower
        self.upper = upper
        self.state = 0
        self.cost_tensor = cost_tensor
        self.constraint_l = constraint_tensor_left
        self.constraint_r = constraint_tensor_right
        self.N = N
    def reset(self):
        self.ve = np.random.uniform(0, 3.5)  # 初始化控制车速度
        self.vf = np.random.uniform(0.5, 3)  # 初始化被跟踪车速度
        self.error = np.random.uniform(1.5,2.5)  # 初始化两车间距
        self.state = torch.tensor([[self.ve], [self.vf], [self.error]])
        return self.state
    def step(self,action):#使用输入值更新状态
        dist = torch.nn.init.trunc_normal_(torch.empty(1, 1), mean=self.mu, std=self.sigma, a=self.lower, b=self.upper)
        self.state = torch.matmul(self.A, self.state)+torch.matmul(self.B, action)+torch.matmul(self.D, dist) #列向量
        reward = torch.matmul(self.cost_tensor, self.state) # 标量
        done = self.state[-1,0] <= 0              # 标量
        return self.state, reward, done

    def seed(self, seed_value):
        np.random.seed(seed_value)

class PolicyNet(torch.nn.Module): # 需要行向量
    def __init__(self, state_dim, hidden_dim, action_dim):
        super(PolicyNet,self).__init__()
        self.fc1 = torch.nn.Linear(state_dim,hidden_dim)
        self.fc2_mu = torch.nn.Linear(hidden_dim,action_dim)
        self.fc2_sigma = torch.nn.Linear(hidden_dim,action_dim)

    def forward(self,x):
        x = F.relu(self.fc1(x))
        mu = self.fc2_mu(x)
        sigma = F.softplus(self.fc2_sigma(x))+1e-5#输出具有非负平滑的性质
        return mu, sigma

class ValueNet(torch.nn.Module): # 需要行向量
    def __init__(self, state_dim, action_dim, hidden_dim):
        super(ValueNet,self).__init__()
        self.fc1 = torch.nn.Linear(state_dim+action_dim,hidden_dim)
        self.fc2 = torch.nn.Linear(hidden_dim,1)
    def forward(self,s,a):
        x = torch.cat((s,a),-1)
        x = F.relu(self.fc1(x))
        return self.fc2(x)
class CCAC:

    def __init__(self,state_dim,hidden_dim,action_dim,actor_lr,critic_lr,device,action_lower,action_upper,gamma,N,A,B,D,cost_tensor,delta,constraint_tensor_left,constraint_tensor_right):
        self.actor = PolicyNet(state_dim,hidden_dim, action_dim).to(device)
        self.critic = ValueNet(state_dim,action_dim, hidden_dim).to(device)
        self.actor_optimizer = torch.optim.Adam(self.actor.parameters(),lr = actor_lr)
        self.critic_optimizer = torch.optim.Adam(self.critic.parameters(),lr = critic_lr)
        self.gamma = gamma
        self.device = device
        self.action_lower = action_lower
        self.action_upper = action_upper
        self.N = N
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.hidden_dim = hidden_dim
        self.A = A
        self.B = B
        self.D = D
        self.cost_tensor = cost_tensor
        self.actor_lr = actor_lr
        self.critic_lr = critic_lr
        self.critic_time = 0
        self.actor_time = 0
        self.cy_time = 0
        self.num = 0
        self.eta = 10
        self.b_k = 0
        self.delta = delta
        self.p_s = []
        self.actor_loss_list = []
        self.Jc = []
        self.Jr = []
        self.forward = []
        self.mean_ps = []
        self.mean_jr = []
        self.mean_jc = []
        self.constraint_l = constraint_tensor_left
        self.constraint_r = constraint_tensor_right
    def take_action(self,state):
        mu, sigma = self.actor(state)#好像自动就用forward了
        #print('ka?action_dist?')
        action_dist = TruncatedNormal(mu,sigma,1,self.action_lower,self.action_upper)
        action = action_dist.rsample()
        #print('没有')
        #dot = make_dot(action, params=dict(self.actor.named_parameters()))
        #dot.render("actor_param", format="png")  # 保存为 PNG 文件
        return mu, sigma, action

    def update(self, transition_dict,cy_time,num,k):#利用采样值更新更新网络
        self.b_k = min(1e4*1.01**k,1e5)
        #self.b_k = 1e4
        self.cy_time+=cy_time
        self.num+=num
        rows = len(transition_dict['rewards'])#一次更新收集到的总数据数量（episode的长度）
        #辅助矩阵
        #dot = make_dot(transition_dict['next_states'][0], params=dict(self.actor.named_parameters()))
        #dot.render("actor_param_nextstates", format="png")  # 保存为 PNG 文件
        #到这也是可以的
        diagonal_matrix = construct_matrix(rows,1,self.gamma,self.N)
        states = torch.cat(transition_dict['states'],dim=1).transpose(0,1).to(self.device)
        actions = torch.cat(transition_dict['actions'],dim=1).transpose(0,1).to(self.device)
        rewards = torch.stack(transition_dict['rewards']).to(self.device)
        next_states = torch.cat(transition_dict['next_states'],dim=1).transpose(0,1)
        #测试用的，太大了画不出来计算图
        #next_state = torch.cat(transition_dict['next_states'][:2],dim=1).transpose(0,1)

        #dot = make_dot(next_state, params=dict(self.actor.named_parameters()))
        #dot.render("ab2", format="png")  # 保存为 PNG 文件
        rewards_in_use = torch.matmul(diagonal_matrix, rewards).to(self.device) #这个挺有用的，在actor的更新里也能用，52*1
        V_plus = self.critic(next_states.detach()[-(rows-self.N+1):], actions.detach()[-(rows-self.N+1):])
        td_target = rewards_in_use + (self.gamma**self.N) * V_plus #多数据训练
        V_common = self.critic(states.detach()[:rows-self.N+1], actions.detach()[:rows-self.N+1])
        #end_time = time.time()
        #elapsed_time = end_time - start_time
        #print(f"列表数据处理用时：{elapsed_time:.4f} 秒")
        # 梯度部分
        # 更新Critic网络
        start_time = time.time()
        critic_loss = torch.mean(F.mse_loss(V_common, td_target.detach().to(torch.float32)))# 强化学习的更新公式里不考虑值函数对actor网络的求导
        self.critic_optimizer.zero_grad()
        critic_loss.backward()#顺序来说应该是先更新Q再更新\pi吧，这里目标是拿到是对w的导数
        torch.nn.utils.clip_grad_norm_(self.critic.parameters(), max_norm=1)# 先把critic网络的参数更新好，这个和一般AC是一样的。
        self.critic_optimizer.step()#Critic网络更新完毕
        end_time = time.time()
        elapsed_time = end_time - start_time
        self.critic_time += elapsed_time
        #print(f"critic网络更新用时：{elapsed_time:.4f} 秒")
        # 更新Actor网络
        # 加入约束2024/10/10 10:29
        M = rows-self.N+1#只看后面，前面不看，因为用来取代价的只用了后面
        #计算h(s')
        h_s = torch.stack([constraint_function(row,self.constraint_l) for row in next_states])#每个点的约束值
        result = (h_s>2).float()#每个点满足约束取1，不满足取0
        # 这往下三行是N步均值的2024/10/11
        # 下面计算每组约束满足概率的情况，即N个加一起的均值大于1-delta
        add_matrix = construct_matrix(rows, 1, 1, self.N)
        p_s_matrix = torch.matmul(add_matrix, result) #这行是N步为一组，每组满足设定概率的情况，都满足是N，不都满足小于N
        m = torch.sum(p_s_matrix == self.N)#整体全都满足的数量
        p_s = m/M#满足约束的概率
        #下面研究jc的表述(用另一篇文章里的phi和PHI那个)10/14，13：49
        phi = torch.stack([phi_function(row, self.constraint_r) for row in h_s])
        windows = phi.unfold(0, self.N, 1)
        # 计算每个窗口的乘积，并返回到一个新向量
        PHI = torch.prod(windows, dim=2)

        #JC_sigmoid = torch.stack([torch.sigmoid(-self.eta * (row - 2)) for row in h_s])  # 这行是每个约束反向满足概率的情况，不满足是1，满足是0.用sigmoid代表c
        #JC_matrix = torch.matmul(add_matrix, JC_sigmoid)
        J_r = torch.mean(rewards_in_use+self.gamma**self.N*self.critic(next_states[-(rows-self.N+1):], actions[-(rows-self.N+1):]))
        forward = self.b_k * torch.max(1 - self.delta - p_s.detach(), torch.zeros(1))
        J_c = forward*torch.mean(-PHI)
        self.Jc.append(J_c)
        self.Jr.append(J_r.unsqueeze(0))
        self.forward.append(forward)
        #dot = make_dot(J_c, params=dict(self.actor.named_parameters()))
        #dot.render("Jc", format="png")  # 保存为 PNG 文件
        #这里可以看到JC确实是会影响actor参数theta的梯度的
        start_time = time.time()
        actor_loss = -(J_r+J_c)#10.8.21.07，写J的表达式
        #actor_loss = -(J_r)
        #actor_loss = forward * J_c
        #actor_loss = torch.mean(forward*J_c)#Jc是惩罚项，它该越发小，平常应该>0
        #默认梯度下降为什么会actorloss会越来越大呢
        #self.actor_loss_list.append(actor_loss.unsqueeze(0))
        self.actor_loss_list.append(actor_loss)
        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.actor.parameters(), max_norm=1)
        self.actor_optimizer.step()# Adam默认是梯度下降！！想要求max需要在actorloss加个负号！！！
        end_time = time.time()
        elapsed_time = end_time - start_time
        self.actor_time += elapsed_time
        self.p_s.append(p_s.unsqueeze(0))
        if ((k) % little_update) == 0:
            #print('里面k:',k)
            print(f"\n当前机会约束满足概率均值为{torch.mean(torch.cat(self.p_s[-little_update:]), dim=0)}")
            print(f"当前actor_loss均值为{torch.mean(torch.cat(self.actor_loss_list[-little_update:]), dim=0)}")
            print(f"当前Jr均值为{torch.mean(torch.cat(self.Jr[-little_update:]), dim=0)}")
            print(f"当前Jc均值为{torch.mean(torch.cat(self.Jc[-little_update:]), dim=0)}")
            self.mean_ps.append(torch.mean(torch.cat(self.p_s[-little_update:]), dim=0))
            self.mean_jr.append(torch.mean(torch.cat(self.Jr[-little_update:]), dim=0))
            self.mean_jc.append(torch.mean(torch.cat(self.Jc[-little_update:]), dim=0))

def compute_digits(tensor):
    digits = torch.floor(torch.log10(torch.abs(tensor)))
    return 10**digits

def constraint_function(row,constraint_l):
    h=constraint_l.transpose(0,1)
    return torch.matmul(row, h)
def phi_function(row,constraint_r):
    b_1 = 0.17
    b_2 = 0.17
    tao = 0.03
    return (1+b_1*tao)/(1+b_2*tao*torch.exp(-(row-constraint_r)/tao))
def train_on_policy_agent(env, agent, num_episodes, times, little_update, longest, shortest):
    return_list = []
    for i in range(times):
        with tqdm(total=int(num_episodes/times), desc='Iteration %d' % i) as pbar:
            for i_episode in range(int(num_episodes/times)):
                start_time = time.time()
                length = shortest
                while length <= shortest:
                    episode_return = 0
                    transition_dict = {'states': [], 'actions': [], 'next_states': [], 'rewards': [], 'dones': [],
                                       'mu': [], 'sigma': []}
                    done = False
                    num = 0
                    state = env.reset()  # env中reset的状态形状是列向量
                    while (not done) and (num <= longest): #一个trajectory的数据记录
                        num += 1
                        mu, sigma, action = agent.take_action(state.transpose(0,1))#mu是用state_can_grad算出来的，因此mu后续的操作结果进行反向传播应该会累计梯度到state_can_grad上

                        next_state, reward, done = env.step(action) # 输出是列，需要转成行
                        #dot = make_dot(next_state, params=dict(agent.actor.named_parameters()))
                        #dot.render("actor_param_nextstate", format="png")  # 保存为 PNG 文件
                        transition_dict['states'].append(state)
                        transition_dict['actions'].append(action)
                        transition_dict['next_states'].append(next_state)
                        transition_dict['rewards'].append(reward)
                        transition_dict['dones'].append(done)
                        transition_dict['mu'].append(mu)
                        transition_dict['sigma'].append(sigma)
                        #dot = make_dot(transition_dict['next_states'][-1], params=dict(agent.actor.named_parameters()))
                        #dot.render("actor_param_nextstate", format="png")  # 保存为 PNG 文件
                        state = next_state
                        episode_return += reward
                    mu, sigma, action = agent.take_action(state.view(1,-1))
                    transition_dict['actions'].append(action)
                    transition_dict['mu'].append(mu)
                    transition_dict['sigma'].append(sigma)
                    length = len(transition_dict['rewards'])
                return_list.append(episode_return)
                end_time = time.time()
                cy_time = end_time-start_time
                #print(f"无模型单次采样时间:{cy_time:.4f} 秒")
                #dot = make_dot(transition_dict['next_states'][0], params=dict(agent.actor.named_parameters()))
                #dot.render("actor_param_nextstate", format="png")  # 保存为 PNG 文件
                #这里可以画
                agent.update(transition_dict,cy_time,num,num_episodes/times * i+i_episode+1)
                if ((i_episode+1) % little_update) == 0:
                    #print('外面i_episode:',i_episode)
                    #print('外面k:', num_episodes/times * i+i_episode+1)
                    pbar.set_postfix({'episode': '%d' % (num_episodes/times * i + i_episode + 1),
                                      'return': '%.3f' % torch.mean(torch.cat(return_list[-little_update:],dim=0))
                                    })
                pbar.update(1)


    return return_list
# 后续还要对梯度的更新方程进行修改，改成CCAC的
# 具体实现：
actor_lr = 1e-5
critic_lr = 2e-4
num_episodes = 2100
little_update = 30
times = int(num_episodes/little_update)

hidden_dim = 128
gamma = 0.98
device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")
T = 0.1
N = 80
dyn_A = torch.tensor([[1, 0, 0], [0, 1, 0], [-T, T, 1]], dtype=torch.float32)
dyn_B = torch.tensor([[T, 0, 0]], dtype=torch.float32).view(-1, 1)
dyn_D = torch.tensor([[0, 0, T]], dtype=torch.float32).view(-1, 1)
state_dim = dyn_A.shape[0]
action_dim = dyn_B.shape[1]
mu = 0
sigma = 1
lower = -5
upper = 5
action_lower = -4
action_upper = 3
cost_tensor = torch.tensor([0.2, 0, -0.05], dtype=torch.float32)
constraint_tensor_left = torch.tensor([[0, 0, 1]], dtype=torch.float32)
constraint_tensor_right = 2
delta = 0.1

shortest = N+10
longest = N+200
env = dynamic(dyn_A, dyn_B, dyn_D, state_dim, action_dim,mu,sigma,lower,upper,cost_tensor,constraint_tensor_left,constraint_tensor_right,N)
env.seed(0)
torch.manual_seed(0)
agent = CCAC(state_dim, hidden_dim, action_dim, actor_lr, critic_lr, device, action_lower, action_upper, gamma, N,dyn_A,dyn_B,dyn_D,cost_tensor,delta,constraint_tensor_left,constraint_tensor_right)

return_list = train_on_policy_agent(env, agent, num_episodes, times, little_update, longest ,shortest)
print(f"critic更新总用时:{agent.critic_time}秒")
print(f"actor更新总用时:{agent.actor_time}秒")
print(f"采样总用时:{agent.cy_time}秒")
print(f"采样总次数:{agent.num}次")
#print(f"最终约束满足概率:{agent.p_s}")
plt.figure(1)
episodes_list = list(range(len(return_list)))
return_list_plot = [t.item() for t in return_list]
plt.plot(episodes_list, return_list_plot)
plt.xlabel('Iteration')
plt.ylabel('Returns')
plt.title('CCAC on {}'.format(env))

plt.figure(2)
mv_return = rl_utils.moving_average(return_list_plot, 9)
plt.plot(episodes_list, mv_return)
plt.xlabel('Iteration')
plt.ylabel('Returns')
plt.title('CCAC on {}'.format(env))

plt.figure(3)
p_s_list = list(range(len(agent.p_s)))
p_s_plot = [p_s.item() for p_s in agent.p_s]
plt.plot(p_s_list, p_s_plot)
plt.xlabel('Iteration')
plt.ylabel('p_s')
plt.title('constraints')

plt.figure(4)
Jc_list = list(range(len(agent.Jc)))
Jc_plot = [Jc.item() for Jc in agent.Jc]
plt.plot(Jc_list, Jc_plot)
plt.xlabel('Iteration')
plt.ylabel('JC')
plt.title('JC')

plt.figure(5)
Jr_list = list(range(len(agent.Jr)))
Jr_plot = [Jr.item() for Jr in agent.Jr]
plt.plot(Jr_list, Jr_plot)
plt.xlabel('Iteration')
plt.ylabel('Jr')
plt.title('JR')

plt.figure(6)
mean_ps_list = list(range(len(agent.mean_ps)))
mean_ps_plot = [mean_ps.item() for mean_ps in agent.mean_ps]
plt.plot(mean_ps_list, mean_ps_plot)
plt.xlabel('Iteration')
plt.ylabel('mean_ps')
plt.title('mean_ps')

plt.figure(8)
mean_jr_list = list(range(len(agent.mean_jr)))
mean_jr_plot = [mean_jr.item() for mean_jr in agent.mean_jr]
plt.plot(mean_jr_list, mean_jr_plot)
plt.xlabel('Iteration')
plt.ylabel('mean_jr')
plt.title('mean_jr')

plt.figure(9)
mean_jc_list = list(range(len(agent.mean_jc)))
mean_jc_plot = [mean_jc.item() for mean_jc in agent.mean_jc]
plt.plot(mean_jc_list, mean_jc_plot)
plt.xlabel('Iteration')
plt.ylabel('mean_jc')
plt.title('mean_jc')
plt.show()




