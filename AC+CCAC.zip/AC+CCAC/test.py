import random
import numpy as np
import collections
from tqdm import tqdm
import scipy.stats as stats
import torch
from torch import tensor
import torch.nn.functional as F
import matplotlib.pyplot as plt
import rl_utils
from torchviz import make_dot

from torchrl.modules import TruncatedNormal
# 示例数据，启用梯度追踪
import torch
constraint_tensor_left = torch.tensor([[0, 0, 1]], dtype=torch.float32)
def phi_function(row,constraint_tensor_left):
    b_1 = 0.17
    b_2 = 0.17
    tao = 0.03
    return (1+b_1*tao)/(1+b_2*tao*torch.exp(-row/tao))

row = torch.arange(-5, 1.01, 0.01)

# 计算 phi_function 的结果
result = phi_function(row, constraint_tensor_left)
print(result)

